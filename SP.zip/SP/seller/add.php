<?php
// 導入資料庫連線
require __DIR__ . '/components/connectToSql.php';
$pageName = "add";
$title = "新增";

include __DIR__ . "/components/head.php";
?>

<style>
    form .mb-3 .form-text {
        color: red;
    }

    .is-invalid {
        border: 1px solid red;
    }
</style>

<div class="container mt-3">
    <h2>新增賣家資料</h2>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h5 class="card-title">新增資料</h5>
                    <form name="form1" method="post" action="add-api.php" enctype="multipart/form-data">

                        <div class="mb-3">
                            <label for="name" class="form-label">攤位名稱</label>
                            <input type="text" class="form-control" id="name" name="name">
                            <div class="form-text"></div>
                        </div>

                        <div class="mb-3">
                            <label for="company_name" class="form-label">公司名稱</label>
                            <input type="text" class="form-control" id="company_name" name="company_name">
                            <div class="form-text"></div>
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">電子信箱</label>
                            <input type="text" class="form-control" id="email" name="email">
                            <div class="form-text"></div>
                        </div>

                        <div class="mb-3">
                            <label for="address" class="form-label">攤位地址</label>
                            <input type="text" class="form-control" id="address" name="address">
                            <div class="form-text"></div>
                        </div>

                        <div class="mb-3">
                            <label for="profile_picture" class="form-label">上傳圖片</label>
                            <input type="file" class="form-control" id="profile_picture" name="image">
                            <div class="form-text"></div>
                        </div>

                        <div class="mb-3">
                            <label for="introduction" class="form-label">攤位簡介</label>
                            <textarea class="form-control" id="introduction" name="introduction" rows="3"></textarea>
                            <div class="form-text"></div>
                        </div>

                        <div class="mb-3">
                            <label for="phone" class="form-label">連絡電話</label>
                            <input type="text" class="form-control" id="phone" name="phone">
                            <div class="form-text"></div>
                        </div>

                        <div class="business-hours-container">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="select-container">
                                        <label for="business_hours_start">開始時間：</label>
                                        <select name="business_hours_start" id="business_hours_start">
                                            <?php
                                            // 產生 24 小時的選項
                                            for ($i = 0; $i < 24; $i++) {
                                                $startHour = sprintf("%02d", $i);
                                                echo "<option value='$startHour'>$startHour:00</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="select-container">
                                        <label for="business_hours_end">結束時間：</label>
                                        <select name="business_hours_end" id="business_hours_end">
                                            <?php
                                            // 產生 24 小時的選項
                                            for ($i = 0; $i < 24; $i++) {
                                                $endHour = sprintf("%02d", $i);
                                                echo "<option value='$endHour'>$endHour:00</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div   class="d-flex justify-content-between">
                              <div>
                                <button type="submit" class="btn btn-primary">新增資料</button>
                              </div>

                            <div class="mt-1">
                            <a href="list.php" >回到產品列表</a>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">新增結果</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-success" role="alert">
                        新增成功
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">繼續新增</button>
                    <a type="button" class="btn btn-primary" href="list.php">到列表頁</a>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
function sendForm(event) {
    event.preventDefault();

    console.log("Sending form data...");

    const fd = new FormData(document.forms.form1);
    fetch('add-api.php', {
        method: 'POST',
        body: fd,
    })
        .then(r => r.json())
        .then(result => {
            console.log("Response from server:", result);
            if (result.success) {
                // 清除表單輸入的資料
                document.forms.form1.reset();
                // 跳轉到 list.php
                window.location.href = 'list.php';
            }
        })
        .catch(e => console.log("Error:", e));

    return false;
}
</script>
<?php include __DIR__ . "/components/scripts.php"?>
<?php include __DIR__ . "/components/foot.php" ?>
