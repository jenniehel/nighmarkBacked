<?php
// 導入資料庫連線
require __DIR__ . '/components/connectToSql.php';
$pageName = "edit";
$title = "編輯";

include __DIR__ . "/components/head.php";

// 取得要編輯的資料
if (!empty($_GET['seller_id'])) {
    $seller_id = intval($_GET['seller_id']);
    $sql = "SELECT * FROM `sellers` WHERE `seller_id` = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$seller_id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        // 找不到要編輯的資料，轉向至列表頁
        header('Location: list.php');
        exit;
    }
} else {
    // 沒有提供 seller_id，轉向至列表頁
    header('Location: list.php');
    exit;
}

// 表單未提交，使用 $row 中的資料預設顯示
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_POST = $row;
}

// 先定義變量，避免未定義的錯誤
$name = isset($_POST['name']) ? $_POST['name'] : '';
$company_name = isset($_POST['company_name']) ? $_POST['company_name'] : '';
$email = isset($_POST['email']) ? $_POST['email'] : '';
$address = isset($_POST['address']) ? $_POST['address'] : '';
$introduction = isset($_POST['introduction']) ? $_POST['introduction'] : '';
$phone = isset($_POST['phone']) ? $_POST['phone'] : '';
$business_hours_start = isset($_POST['business_hours_start']) ? $_POST['business_hours_start'] : '';
$business_hours_end = isset($_POST['business_hours_end']) ? $_POST['business_hours_end'] : '';
$image_url = isset($_POST['current_image']) ? $_POST['current_image'] : '';

// 編輯成功的提示訊息
$editMessage = '';

// 提交表單後的處理
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 檢查是否有變更
    $isDataChanged = false;

    // 判斷是否有任何欄位被編輯
    foreach ($row as $key => $value) {
        if (isset($_POST[$key]) && $_POST[$key] !== $value) {
            $isDataChanged = true;
            break;
        }
    }

    if ($isDataChanged) {
        // 有變更，執行更新

        // 檢查是否有選擇新圖片
        if (isset($_FILES['image_url']) && $_FILES['image_url']['name'] !== '') {
            // 如果有選擇新圖片，先處理上傳
            $uploadDir = __DIR__ . '/upload/';
            $uploadFile = $uploadDir . basename($_FILES['image_url']['name']);

            // 移動上傳的檔案
            if (move_uploaded_file($_FILES['image_url']['tmp_name'], $uploadFile)) {
                // 上傳成功，更新 image_url
                $image_url = basename($_FILES['image_url']['name']);
            } else {
                // 上傳失敗，這裡可以進行錯誤處理
                $editMessage = '圖片上傳失敗';
            }
        } else {
            // 如果沒有選擇新圖片，保留原有的圖片
            $image_url = $_POST['current_image'];
        }

        // 更新其他資料
        $sql = "UPDATE `sellers` SET 
            `name` = ?,
            `company_name` = ?,
            `email` = ?,
            `address` = ?,
            `profile_picture` = ?,
            `introduction` = ?,
            `phone` = ?,
            `business_hours_start` = ?,
            `business_hours_end` = ?
            WHERE `seller_id` = ?";

        $stmt = $pdo->prepare($sql);

        try {
            $stmt->execute([
                $name,
                $company_name,
                $email,
                $address,
                $image_url,
                $introduction,
                $phone,
                $business_hours_start,
                $business_hours_end,
                $seller_id,
            ]);

            // 更新成功，設定編輯成功的提示訊息
            $editMessage = '編輯成功';

        } catch (PDOException $e) {
            // SQL 錯誤
            $editMessage = 'SQL 有東西出錯了' . $e->getMessage();
        }
    } else {
        // 沒有變更
        $editMessage = '資料未變更';
    }
}
?>

<style>
    form .mb-3 .form-text {
        color: red;
    }

    .is-invalid {
        border: 1px solid red;
    }
</style>

<div class="container mt-3">
    <h2>編輯資料</h2>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h5 class="card-title">編輯資料</h5>
                    <?php if (isset($editMessage)): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo $editMessage; ?>
                        </div>
                    <?php endif; ?>
                    <form name="form1" method="post" action="edit.php?seller_id=<?php echo $seller_id; ?>"
                        enctype="multipart/form-data">

                        <div class="mb-3">
                            <label for="name" class="form-label">攤位名稱</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo $name; ?>">
                            <div class="form-text"></div>
                        </div>

                        <div class="mb-3">
                            <label for="company_name" class="form-label">公司名稱</label>
                            <input type="text" class="form-control" id="company_name" name="company_name"
                                value="<?php echo $company_name; ?>">
                            <div class="form-text"></div>
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">電子信箱</label>
                            <input type="text" class="form-control" id="email" name="email"
                                value="<?php echo $email; ?>">
                            <div class="form-text"></div>
                        </div>

                        <div class="mb-3">
                            <label for="address" class="form-label">攤位地址</label>
                            <input type="text" class="form-control" id="address" name="address"
                                value="<?php echo $address; ?>">
                            <div class="form-text"></div>
                        </div>


                        <div class="mb-3">
                            <label for="image" class="form-label">賣家圖片</label>
                            <input type="file" class="form-control" id="image" name="image">
                            <div class="form-text"></div>
                        </div>

                        <div class="mb-3">
                            <label for="current_image" class="form-label">目前圖片</label>
                            <img src="upload/<?php echo $row['profile_picture']; ?>" alt="Current Image"
                                style="max-width: 100px;">
                            <input type="hidden" name="current_image" value="<?php echo $row['profile_picture']; ?>">
                        </div>

                        <div class="mb-3">
                            <label for="introduction" class="form-label">攤位簡介</label>
                            <textarea class="form-control" id="introduction" name="introduction"
                                rows="3"><?php echo $introduction; ?></textarea>
                            <div class="form-text"></div>
                        </div>

                        <div class="mb-3">
                            <label for="phone" class="form-label">連絡電話</label>
                            <input type="text" class="form-control" id="phone" name="phone"
                                value="<?php echo $phone; ?>">
                            <div class="form-text"></div>
                        </div>

                        <div class="business-hours-container">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="select-container">
                                        <label for="business_hours_start">開始時間：</label>
                                        <select name="business_hours_start" id="business_hours_start">
                                            <?php
                                            // 產生 24 小時的選項
                                            for ($i = 0; $i < 24; $i++) {
                                                $startHour = sprintf("%02d", $i);
                                                echo "<option value='$startHour' " . ($startHour == $business_hours_start ? 'selected' : '') . ">$startHour:00</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="select-container">
                                        <label for="business_hours_end">結束時間：</label>
                                        <select name="business_hours_end" id="business_hours_end">
                                            <?php
                                            // 產生 24 小時的選項
                                            for ($i = 0; $i < 24; $i++) {
                                                $endHour = sprintf("%02d", $i);
                                                echo "<option value='$endHour' " . ($endHour == $business_hours_end ? 'selected' : '') . ">$endHour:00</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-between">
                            <div>
                                <button type="submit" class="btn btn-primary">更新数据</button>
                            </div>

                            <div class="mt-1">
                                <a href="list.php">回到賣家列表</a>
                            </div>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . "/components/scripts.php" ?>