<?php
// 导入数据库连接
require __DIR__ . '/components/connectToSql.php';

// 获取卖家ID
$seller_id = isset($_GET['seller_id']) ? intval($_GET['seller_id']) : 0;

// 如果没有提供卖家ID，返回错误信息
if ($seller_id <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid seller ID']);
    exit;
}

// 查询数据库，获取卖家信息
$sql = "SELECT * FROM `sellers` WHERE `seller_id` = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$seller_id]);
$seller = $stmt->fetch(PDO::FETCH_ASSOC);

// 如果没有找到卖家，返回错误信息
if (!$seller) {
    echo json_encode(['status' => 'error', 'message' => 'Seller not found']);
    exit;
}

// 处理表单提交
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 获取用户输入
    $name = $_POST['name'];
    $company_name = $_POST['company_name'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $introduction = $_POST['introduction'];
    $phone = $_POST['phone'];
    $business_hours_start = $_POST['business_hours_start'];
    $business_hours_end = $_POST['business_hours_end'];

    // 檢查是否有選擇新圖片
    if ($_FILES['image']['name'] !== '') {
        // 如果有選擇新圖片，先處理上傳
        $uploadDir = __DIR__ . '/upload/';
        $uploadFile = $uploadDir . basename($_FILES['image']['name']);

        // 移動上傳的檔案
        if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadFile)) {
            // 上傳成功，更新 image
            $profile_picture = basename($_FILES['image']['name']);
        } else {
            // 上傳失敗，返回錯誤信息
            echo json_encode(['status' => 'error', 'message' => 'Image upload failed']);
            exit;
        }
    } else {
        // 如果沒有選擇新圖片，保留原有的圖片
        $profile_picture = $seller['profile_picture'];
    }

    // 更新卖家信息
    $updateSql = "UPDATE `sellers` SET 
        `name` = ?,
        `company_name` = ?,
        `email` = ?,
        `address` = ?,
        `profile_picture` = ?,
        `introduction` = ?,
        `phone` = ?,
        `business_hours_start` = ?,
        `business_hours_end` = ?
        WHERE `seller_id` = ?";

    $updateStmt = $pdo->prepare($updateSql);

    try {
        $updateStmt->execute([
            $name,
            $company_name,
            $email,
            $address,
            $profile_picture,
            $introduction,
            $phone,
            $business_hours_start,
            $business_hours_end,
            $seller_id,
        ]);

        // 更新成功，返回成功信息
        echo json_encode(['status' => 'success', 'message' => 'Seller updated successfully']);

    } catch (PDOException $e) {
        // SQL 错误，返回错误信息
        echo json_encode(['status' => 'error', 'message' => 'SQL error: ' . $e->getMessage()]);
    }

} else {
    // 如果不是 POST 请求，返回错误信息
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
}
