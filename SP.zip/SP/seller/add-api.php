<?php
require __DIR__ . '/components/connectToSql.php';
$uploadDir = __DIR__ . '/upload/';
header("Content-Type: application/json");

$output = [
    "success" => false,
    "error" => "",
    "code" => 0,
    "postData" => $_POST,
    "errors" => [],
];

// 收集表單数据
$name = $_POST['name'] ?? '';
$company_name = $_POST['company_name'] ?? '';
$email = $_POST['email'] ?? '';
$address = $_POST['address'] ?? '';
$introduction = $_POST['introduction'] ?? '';
$phone = $_POST['phone'] ?? '';
$business_hours_start = $_POST['business_hours_start'] ?? '';
$business_hours_end = $_POST['business_hours_end'] ?? '';

$startTime = empty($business_hours_start) ? null : $business_hours_start . ':00';
$endTime = empty($business_hours_end) ? null : $business_hours_end . ':00';



// 處理圖片上傳
$profilePicture = null;

if (!empty($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
    $uploadDir = rtrim($uploadDir, '/') . '/'; // 確保 $uploadDir 有斜線結尾

    $profilePicture = $uploadDir . uniqid() . '_' . basename($_FILES['image']['name']);

    if (move_uploaded_file($_FILES['image']['tmp_name'], $profilePicture)) {
        // 檔案成功移動，可以繼續處理
    } else {
        $output['error'] = '圖片上傳失敗';
        echo json_encode($output, JSON_UNESCAPED_UNICODE);
        exit;
    }
}

// 準備 SQL 指令
$sql = "INSERT INTO `sellers` (`name`, `company_name`, `email`, `address`, `profile_picture`, `introduction`, `phone`, `business_hours_start`, `business_hours_end`, `created_at`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";

$stmt = $pdo->prepare($sql);

try {
    $stmt->execute([
        $name,
        $company_name,
        $email,
        $address,
        $profilePicture,
        $introduction,
        $phone,
        $startTime,
        $endTime,
    ]);

    $output['success'] = boolval($stmt->rowCount());

    if ($output['success']) {
        $output['message'] = '新增成功';
        header("Location: list.php");
        exit;
    }
} catch (PDOException $e) {
    $output['error'] = 'SQL 有東西出錯了' . $e->getMessage();
    $output['success'] = false;
}

echo json_encode($output, JSON_UNESCAPED_UNICODE);
