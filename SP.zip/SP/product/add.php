<?php
// 导入数据库连接
require __DIR__ . '/components/connectToSql.php';

// 定义变量以存储用户输入
$product_name = $category = $description = $image_url = $price = $stock_quantity = $listing_date = '';

// 处理表单提交
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 获取用户输入
    $product_name = $_POST['product_name'];
    $category = $_POST['category'];
    $description = $_POST['description'];
    $image_url = $_POST['image_url'];
    $price = $_POST['price'];
    $stock_quantity = $_POST['stock_quantity'];
    $listing_date = $_POST['listing_date'];

    // 添加产品到数据库
    $sql = "INSERT INTO products (product_name, category, product_description, image_url, price, stock_quantity, listing_date)
            VALUES (:product_name, :category, :description, :image_url, :price, :stock_quantity, :listing_date)";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':product_name', $product_name, PDO::PARAM_STR);
    $stmt->bindParam(':category', $category, PDO::PARAM_STR);
    $stmt->bindParam(':description', $description, PDO::PARAM_STR);
    $stmt->bindParam(':image_url', $image_url, PDO::PARAM_STR);
    $stmt->bindParam(':price', $price, PDO::PARAM_INT);
    $stmt->bindParam(':stock_quantity', $stock_quantity, PDO::PARAM_INT);
    $stmt->bindParam(':listing_date', $listing_date, PDO::PARAM_STR);

    if ($stmt->execute()) {
        // 添加成功，重定向回产品列表页
        header("Location: list.php");
        exit;
    } else {
        // 添加失败，这里可以进行错误处理
        echo "Failed to add product";
    }
}
?>

<?php include __DIR__ . "/components/head.php"; ?>

<div class="container mt-3">
    <h2>新增產品</h2>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form method="post" action="add-api.php" enctype="multipart/form-data"> <!-- 在这里添加表单输入框，根据需要调整 -->
                        <div class="mb-3">
                            <label for="product_name" class="form-label">產品名稱</label>
                            <input type="text" class="form-control" id="product_name" name="product_name" required>
                        </div>

                        <div class="mb-3">
                            <label for="category" class="form-label">產品類別</label>
                            <!-- 在这里添加下拉菜单，根据需要调整 -->
                            <select class="form-select" id="category" name="category" required>
                                <option value="點心">點心</option>
                                <option value="飲料">飲料</option>
                                <option value="甜品">甜品</option>
                                <option value="湯品">湯品</option>
                                <option value="小吃">小吃</option>
                                <option value="主食">主食</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="product_description" class="form-label">產品敘述</label>
                            <textarea class="form-control" id="product_description" name="product_description"
                                rows="3"></textarea>
                            <div class="form-text"></div>
                        </div>

                        <div class="mb-3">
                            <label for="image_url" class="form-label">產品圖片</label>
                            <input type="file" class="form-control" id="image_url" name="image_url" min="1">
                            <div class="form-text"></div>
                        </div>

                        <div class="mb-3">
                            <label for="price" class="form-label">產品價格</label>
                            <input type="number" class="form-control" id="price" name="price">
                            <div class="form-text"></div>
                        </div>

                        <div class="mb-3">
                            <label for="listing_date" class="form-label">上架日期</label>
                            <input type="date" class="form-control" id="listing_date" name="listing_date" required>
                            <!-- 可以根據需要調整日期輸入的類型 -->
                        </div>

                        <div class="mb-3">
                            <label for="stock_quantity" class="form-label">總數量</label>
                            <input type="text" class="form-control" id="stock_quantity" name="stock_quantity" min="1">
                            <div class="form-text"></div>
                        </div>
                        <div class="d-flex justify-content-between">
                            <div>
                                <button type="submit" class="btn btn-primary">新增資料</button>
                            </div>

                            <div class="mt-1">
                                <a href="list.php">回到產品列表</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>   
    </div>   
</div>
                <?php include __DIR__ . "/components/scripts.php"; ?>