<?php require __DIR__. '/components/connectToSql.php';
$pageName = 'home';
$title = '首頁';

?>
<!-- head -->
<?php include __DIR__ . '/components/head.php'  ?> 

<!-- nav -->

<div class="container">
  <h2>Front Page</h2>

</div>
<?php include __DIR__ . '/components/scripts.php'  ?>
<?php include __DIR__ . '/components/foot.php'  ?>

<!-- 這是首頁  -->