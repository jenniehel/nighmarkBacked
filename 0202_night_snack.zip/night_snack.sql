-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- 主機： 127.0.0.1
-- 產生時間： 2024-02-02 10:57:05
-- 伺服器版本： 10.4.32-MariaDB
-- PHP 版本： 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `night_snack`
--

-- --------------------------------------------------------

--
-- 資料表結構 `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `category` varchar(255) DEFAULT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_description` text DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `price` int(20) NOT NULL,
  `stock_quantity` int(11) NOT NULL,
  `listing_date` date NOT NULL DEFAULT current_timestamp(),
  `status` varchar(50) NOT NULL,
  `seller_id` int(11) DEFAULT NULL,
  `points_price` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `products`
--

INSERT INTO `products` (`product_id`, `category`, `product_name`, `product_description`, `image_url`, `price`, `stock_quantity`, `listing_date`, `status`, `seller_id`, `points_price`, `category_id`) VALUES
(1, '點心', '可麗餅', '酥脆可口的可麗餅', '1_可麗餅.png 的副本.png', 90, 51, '2024-01-08', '上架中', 1, 60, 1),
(2, '飲料', '珍珠奶茶', '香濃奶茶搭配Q彈珍珠', '2_珍珠奶茶.png 的副本.png', 60, 80, '2024-01-21', '上架中', 1, 55, 2),
(3, '小吃', '雞排', '酥脆美味的雞排', '3_雞排.png 的副本.png', 100, 60, '2024-01-21', '上架中', 1, 70, 5),
(4, '飲料', '木瓜牛奶', '香濃牛奶搭配新鮮木瓜', '4_木瓜牛奶.png 的副本.png', 60, 75, '2024-01-21', '上架中', 1, 60, 2),
(5, '小吃', '蚵仔煎', '酥脆美味的台灣小吃', '5_蚵仔煎.png 的副本.png', 50, 40, '2024-01-21', '上架中', 1, 80, 5),
(6, '主食', '火雞肉飯', '美味的火雞肉搭配香噴噴的白飯', '6_火雞肉飯.png 的副本.png', 50, 55, '2024-01-21', '上架中', 2, 65, 6),
(7, '主食', '鱔魚意麵', '美味的鱔魚搭配暖呼呼的意麵', '7_鱔魚意麵.png 的副本.png', 45, 30, '2024-01-21', '上架中', 2, 90, 6),
(8, '小吃', '棺材板', '多種配料的美味烤吐司', '8_棺材板.png 的副本.png', 75, 45, '2024-01-21', '上架中', 2, 70, 5),
(9, '小吃', '潤餅', '台灣傳統美食，薄餅包裹豐富的內餡', '9_潤餅.PNG 的副本.png', 40, 65, '2024-01-21', '上架中', 2, 60, 5),
(10, '點心', '車輪餅', '外酥內軟的台灣傳統點心', '10_車輪餅.PNG 的副本.png', 35, 55, '2024-01-21', '上架中', 2, 50, 1),
(11, '點心', '筒仔米糕', '傳統台灣米糕，美味可口', '11_筒仔米糕.PNG 的副本.png', 35, 70, '2024-01-21', '上架中', 3, 40, 1),
(12, '點心', '黑糖糕', '香甜可口的黑糖糕點心', '12_黑糖糕.PNG 的副本.png', 30, 60, '2024-01-21', '上架中', 3, 45, 1),
(13, '主食', '滷肉飯', '美味的滷肉飯，香氣四溢', '13_滷肉飯.png 的副本.png', 50, 50, '2024-01-21', '上架中', 3, 70, 6),
(14, '湯品', '土魠魚羹', '清爽美味的土魠魚羹湯品', '14_土魠魚羹.png 的副本.png', 50, 40, '2024-01-21', '上架中', 3, 55, 4),
(15, '小吃', '刈包', '台灣傳統美味小吃，虎咬豬，多種配料搭配口感獨特的麵皮', '15_刈包.png 的副本.png', 45, 45, '2024-01-21', '上架中', 3, 75, 5),
(16, '點心', '小籠包', '鮮美的小籠包，湯汁豐富', '16_小籠包.png 的副本.png', 70, 35, '2024-01-21', '上架中', 4, 85, 1),
(17, '小吃', '大腸包小腸', '像熱狗般的「雙腸」組合，讓你每一口都充滿驚奇', '17_大腸包小腸.png 的副本.png', 55, 50, '2024-01-21', '上架中', 4, 65, 5),
(18, '小吃', '臭豆腐', '風靡夜市的台灣特色小吃，炸到金黃香酥的臭豆腐，淋上帶有甜味的蒜蓉醬再搭泡菜後爆表好吃', '18_臭豆腐.png 的副本.png', 45, 40, '2024-01-21', '上架中', 4, 55, 5),
(19, '甜品', '豆花', '清涼爽口，入口即化的豆花 ', '19_豆花.png 的副本.png', 30, 60, '2024-01-21', '上架中', 4, 45, 3),
(20, '主食', '鹽酥雞', '雞肉外脆內嫩的鮮嫩口感，加上獨特的香料調味和配方使每一口都充滿風味，更有九層塔、生蒜碎等，一口咬下鹹香夠味的好滋味，加上多層次的調味，讓人一吃就著迷，忍不住一口接著一口吃不停。', '20_鹽酥雞.png 的副本.png', 120, 50, '2024-01-21', '上架中', 4, 70, 6),
(21, '點心', '地瓜球', '甜蜜美味的地瓜球點心', '21_地瓜球.png 的副本.png', 45, 60, '2024-01-21', '上架中', 5, 45, 1),
(22, '點心', '白糖粿', '由糯米糰製成的白糖粿，油炸過後，熱熱的沾上白糖、花生粉吃，外酥內軟非常好吃', '22_白糖粿.png 的副本.png', 30, 55, '2024-01-21', '上架中', 5, 50, 1),
(23, '主食', '營養三明治', '炸得金黃酥脆的麵包，配上滷蛋、火腿、黃瓜、番茄等內餡，再擠上重頭戲、濃郁的美乃滋，一口咬下，唇齒留香', '23_營養三明治.png 的副本.png', 45, 40, '2024-01-21', '上架中', 5, 80, 6),
(24, '主食', '天婦羅', '日式炸物，外酥內嫩', '24_天婦羅.png 的副本.png', 130, 35, '2024-01-21', '上架中', 5, 85, 6),
(25, '湯品', '肉羹湯', '滑順的羹湯搭配各種脆口的食材，肉條經過香辛料、金黃蒜油裹粉醃漬燙過，口感軟嫩、蒜味濃郁，濃郁的香菇風味使柴魚湯底層次更濃厚豐富！每一口都是滿滿的台灣味', '26_肉羹湯.png 的副本.png', 35, 45, '2024-01-21', '上架中', 5, 65, 4),
(26, '主食', '夜市牛排', '入口即化的牛肉、現炒鐵板麵淋上蘑菇醬、佐營養三色豆，加上一顆生雞蛋，半熟吃實在美味', '27_夜市牛排.png 的副本.png', 120, 30, '2024-01-21', '上架中', 1, 120, 6),
(27, '甜品', '糖葫蘆', '番茄、草莓等食材，外成裹上一層糖衣，吃起來酸甜可口', '28_糖葫蘆.png 的副本.png', 35, 70, '2024-01-21', '上架中', 2, 35, 3),
(28, '小吃', '蔥油餅', '青蔥香氣四溢，配上酥脆有嚼勁的金黃色的餅皮', '29_蔥油餅.png 的副本.png', 55, 55, '2024-01-21', '上架中', 3, 50, 5),
(29, '湯品', '蚵仔麵線', '鮮美的蚵仔配上細緻的麵線湯', '30_蚵仔麵線.png 的副本.png', 60, 40, '2024-01-21', '上架中', 4, 75, 4),
(30, '甜品', '芒果冰', '新鮮芒果搭配豐富配料的冰品', '25_芒果冰.png 的副本.png', 110, 50, '2024-01-21', '上架中', 5, 65, 3);

-- --------------------------------------------------------

--
-- 資料表結構 `product_categories`
--

CREATE TABLE `product_categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `product_categories`
--

INSERT INTO `product_categories` (`category_id`, `category_name`) VALUES
(1, '點心'),
(2, '飲料'),
(3, '甜品'),
(4, '湯品'),
(5, '小吃'),
(6, '主食');

-- --------------------------------------------------------

--
-- 資料表結構 `sellers`
--

CREATE TABLE `sellers` (
  `seller_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `address` text DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `introduction` text DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `business_hours_start` time DEFAULT NULL,
  `business_hours_end` time DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `sellers`
--

INSERT INTO `sellers` (`seller_id`, `name`, `company_name`, `email`, `address`, `image_url`, `introduction`, `phone`, `business_hours_start`, `business_hours_end`, `created_at`) VALUES
(1, '陳小吃攤', '台灣美食有限公司', 'chenxiaochitan@example.com', '台北市夜市區1號攤位', 'https://example.com/chenxiaochi.jpg', '歡迎品嚐我們的美味夜市小吃。', '2', '05:00:00', '22:00:00', '2024-01-29 06:02:53'),
(2, '林小吃攤', '夜市好味有限公司', 'linxiaochitan@example.com', '台中市夜市區2號攤位', 'https://example.com/linxiaochi.jpg', '專業製作各種美味小吃，品質保證。', '4', '05:00:00', '22:00:00', '2024-01-29 06:02:53'),
(3, '張小吃攤', '夜市好味小吃有限公司', 'zhangxiaochitan@example.com', '高雄市夜市區3號攤位', 'https://example.com/zhangxiaochi.jpg', '新鮮食材，美味可口，歡迎光臨。', '72322', '00:00:00', '00:00:00', '2024-01-29 06:02:53'),
(4, '李小吃攤', '夜市好味生活有限公司', 'lixiaochitan@example.com', '新竹市夜市區4號攤位', 'https://example.com/lixiaochi.jpg', '提供健康美味的夜市小吃，您的首選。', '3', '05:00:00', '22:00:00', '2024-01-29 06:02:53'),
(5, '吳小吃攤', '夜市美食樂活有限公司', 'wuxiaochitan@example.com', '彰化市夜市區5號攤位', 'https://example.com/wuxiaochi.jpg', '用心烹飪，樂活美食，歡迎品嚐。', '4', '00:00:13', '00:00:15', '2024-01-29 06:02:53'),
(2299, '攤位名稱', '攤位名稱', '231@gmail.com', '攤位名稱', 'C:\\xampp\\htdocs\\myphp\\SP copy\\seller/uploadSeller/65bbb8e17391a_73320844_p0.jpg', '攤位名稱攤位名稱', '0987654321', '12:00:00', '19:00:00', '2024-02-01 15:29:37'),
(2300, '攤位名稱', '攤位名稱', '231@gmail.com', '攤位名稱', 'C:\\xampp\\htdocs\\myphp\\SP copy\\seller/uploadSeller/65bbb8e51d181_73320844_p0.jpg', '攤位名稱攤位名稱', '0987654321', '12:00:00', '19:00:00', '2024-02-01 15:29:41'),
(2301, '增資', '增資增資', '213@gmail.com', '增資', 'C:\\xampp\\htdocs\\myphp\\SP copy\\seller/uploadSeller/65bbba94b6e1d_73320844_p0.jpg', '增資增資', '0987654321', '09:00:00', '18:00:00', '2024-02-01 15:36:52'),
(2302, '增資', '增資增資', '213@gmail.com', '增資', 'C:\\xampp\\htdocs\\myphp\\SP copy\\seller/uploadSeller/65bbbc2e236dd_73320844_p0.jpg', '增資增資', '0987654321', '00:00:18', '00:00:19', '2024-02-01 15:43:42'),
(2303, '位名稱位名稱', '位名稱位名稱', '123e@gmaiil.com', '位名稱位名稱', 'C:\\xampp\\htdocs\\myphp\\SP copy\\seller/uploadSeller/65bbbc62594fe_73320844_p0.jpg', '位名稱位名稱位名稱', '0976332123', '18:00:00', '19:00:00', '2024-02-01 15:44:34'),
(2304, '新增資料', '新增資料', '123@gmail.com', '新增資料新增資料', 'C:\\xampp\\htdocs\\myphp\\SP copy\\seller/uploadSeller/65bbbfb54f823_73320844_p0.jpg', '新增資料', '0987654321', '00:00:12', '00:00:18', '2024-02-01 15:58:45'),
(2307, '測試版本一', '測試版本一', '8888@gmai.com', '測試版本一', '8d8fa3a5246865b8ac6e5e92e96f19f85239686d.jpg', '測試版本一', '0987654321', '00:00:00', '00:00:00', '2024-02-02 08:42:24'),
(2308, '攤位名稱', '公司名稱', 'texe@gmail.com', '攤位地址', '64142456_p0.jpg', '攤位地址攤位簡介', '0987654321', '15:00:00', '19:00:00', '2024-02-02 09:36:27');

-- --------------------------------------------------------

--
-- 資料表結構 `seller_accounts`
--

CREATE TABLE `seller_accounts` (
  `seller_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `seller_accounts`
--

INSERT INTO `seller_accounts` (`seller_id`, `username`, `password`) VALUES
(1, 'seller1_username', 'seller1_password'),
(2, 'seller2_username', 'seller2_password'),
(3, 'seller3_username', 'seller3_password'),
(4, 'seller4_username', 'seller4_password'),
(5, 'seller5_username', 'seller5_password');

--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `seller_id` (`seller_id`),
  ADD KEY `category_id` (`category_id`);

--
-- 資料表索引 `product_categories`
--
ALTER TABLE `product_categories`
  ADD PRIMARY KEY (`category_id`);

--
-- 資料表索引 `sellers`
--
ALTER TABLE `sellers`
  ADD PRIMARY KEY (`seller_id`);

--
-- 資料表索引 `seller_accounts`
--
ALTER TABLE `seller_accounts`
  ADD PRIMARY KEY (`seller_id`);

--
-- 在傾印的資料表使用自動遞增(AUTO_INCREMENT)
--

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `sellers`
--
ALTER TABLE `sellers`
  MODIFY `seller_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2309;

--
-- 已傾印資料表的限制式
--

--
-- 資料表的限制式 `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`seller_id`) REFERENCES `sellers` (`seller_id`),
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `product_categories` (`category_id`);

--
-- 資料表的限制式 `seller_accounts`
--
ALTER TABLE `seller_accounts`
  ADD CONSTRAINT `seller_accounts_ibfk_1` FOREIGN KEY (`seller_id`) REFERENCES `sellers` (`seller_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
