-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- 主機： localhost:8889
-- 產生時間： 2024 年 01 月 27 日 10:23
-- 伺服器版本： 5.7.39
-- PHP 版本： 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `nightmarket`
--

-- --------------------------------------------------------

--
-- 資料表結構 `ad_auto_close`
--

CREATE TABLE `ad_auto_close` (
  `record_id` int(30) NOT NULL,
  `ad_id` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `ad_auto_close`
--

INSERT INTO `ad_auto_close` (`record_id`, `ad_id`) VALUES
(3, 2),
(5, 1),
(6, 1);

-- --------------------------------------------------------

--
-- 資料表結構 `ad_price`
--

CREATE TABLE `ad_price` (
  `ad_id` int(30) NOT NULL,
  `ad_price` int(30) NOT NULL,
  `deadline` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `ad_price`
--

INSERT INTO `ad_price` (`ad_id`, `ad_price`, `deadline`) VALUES
(1, 1500, 14),
(2, 1000, 7),
(3, 500, 14);

-- --------------------------------------------------------

--
-- 資料表結構 `ad_record`
--

CREATE TABLE `ad_record` (
  `record_id` int(30) NOT NULL,
  `ad_id` int(30) NOT NULL,
  `merchant_Id` int(30) NOT NULL,
  `ad_image` varchar(100) NOT NULL,
  `start_date` date NOT NULL,
  `clicks` int(255) DEFAULT NULL,
  `state` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `ad_record`
--

INSERT INTO `ad_record` (`record_id`, `ad_id`, `merchant_Id`, `ad_image`, `start_date`, `clicks`, `state`) VALUES
(1, 1, 20, '輪播廣告圖_01.png', '2023-06-14', 141, '下架'),
(2, 2, 19, '加購圖01.png', '2023-02-19', 288, '下架'),
(3, 2, 27, '加購圖02.png', '2024-02-05', 158, '上架'),
(4, 3, 9, '漂浮廣告_01.jpg', '2024-01-05', 417, '下架'),
(5, 1, 14, '輪播廣告圖_02.png', '2024-02-06', 126, '上架'),
(6, 1, 1, '輪播廣告圖_03.png', '2024-02-06', 126, '上架');

-- --------------------------------------------------------

--
-- 資料表結構 `comment`
--

CREATE TABLE `comment` (
  `comment_id` int(100) NOT NULL,
  `custom_id` int(100) NOT NULL,
  `merchant_id` int(100) NOT NULL,
  `service_rating` int(10) NOT NULL,
  `product_ratings` int(10) NOT NULL,
  `content` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `recommend_food` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parking` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `comment`
--

INSERT INTO `comment` (`comment_id`, `custom_id`, `merchant_id`, `service_rating`, `product_ratings`, `content`, `recommend_food`, `parking`, `date`) VALUES
(1, 1, 3, 5, 4, '從這家還是在傳統士林夜市裡時就吃到現在，味道不變，只是價格漲了很多，外送的價格也比店內用餐高了些，但是炸天婦羅配小醃小黃瓜片還是一樣好吃，一樣是用新鮮魚漿下去現炸，和市面上的天婦羅口感完全不同，當然如果是在店內用餐，會更好吃，微脆的表皮咬下有魚漿的香味，加上微甜的小黃瓜片，真的很搭配，他家的蚵仔煎，邊邊煎的有些酥脆，煎蛋青菜加上滿滿的蚵仔，再淋上略帶點沙茶味的甜辣醬，一下子就吃光了，至於炒米粉，就比較普通，古早傳統的米粉淋碎滷肉，自己加點辣椒醬，拌一下也很不錯吃，現在點外送平台，滿額還送一杯冰的冬瓜茶。', '松露牛肉堡, 鹽烤薯條 墨式肉醬, 錫蘭紅茶', '附近有機車停車格', '2023-03-13'),
(2, 6, 9, 5, 5, '整體氣氛真的很不錯\r\n熱鬧的夜市感\r\n店內明亮 服務人員也滿親切的！\r\n之後會想內用感受一下氣氛♥️', '黃金蘿蔔糕, 金錢蝦餅', '', '2023-08-29'),
(3, 17, 17, 4, 4, '用餐時間一到店內高朋滿座\r\n甜不辣蠻不錯的但底下滿滿的一層油\r\n臭豆腐上桌溫度稍嫌不夠只有溫溫的\r\n吃起來蠻普通的沒有特別感受\r\n蚵仔煎很脆很香只是醬料有點吃不懂\r\n還點了一個里肌湯挺不錯喝的\r\n但碗裡滿滿的渣渣不知道為什麼？？？\r\n總而言之蠻適合觀光客來嚐鮮多樣台灣小吃\r\n但價格上稍微偏高也沒有想像中好吃', '', '非常難停車', '2024-01-17'),
(4, 8, 4, 4, 4, '剛到士林夜市就看到很多人在排隊，想說晚點再過來吃～沒想到繞完一圈回來就有位置了！吃了綜合煎90$蝦仁只有四個，所以比較推薦蚵仔煎或是蝦仁煎喔～不錯吃。', '', '', '2023-12-20'),
(5, 26, 3, 5, 4, 'IG:doryieat\r\n▪️臭豆腐(小)$35\r\n帶有中藥味的臭豆腐，吃起來很入味\r\n但不是酥脆的，吃起來濕濕軟軟的\r\n▪️生炒花枝羹$100\r\n非常的濃稠，像玉米濃湯\r\n南部口味偏甜\r\n花枝給的很大塊\r\n▪️雞蛋蝦仁煎$80\r\n這個勾芡反而比較少，吃起來就像蝦仁煎蛋', '', '非常難停車', '2023-09-26'),
(6, 11, 3, 2, 3, '炒空心菜，好吃！\r\n生炒花枝羹， 好吃！\r\n麻油豬肚，可以！\r\n蚵仔煎……蚵仔可以，煎不行，蛋過熟，醬不搭。完全不愛！', '黃金蘿蔔糕, 金錢蝦餅', '附近有機車停車格', '2023-12-30'),
(7, 23, 34, 4, 1, '接受信用卡，發票可以存載具，需加收一成服務費\r\n酥皮濃湯無固定出爐時間，只能隨時注意出餐區，但還不錯喝\r\n蛤湯味道普普，蛤很小\r\n竟然有花好月圓（炸湯圓）很特別😂\r\n牛排滿差的，5分熟的肉也還是很難嚼', '酥皮濃湯', '附近有機車停車格', '2023-06-12'),
(8, 18, 9, 4, 3, '種類雖不及我家的菜色多 但是品質都不錯 而且會不斷更換菜色 340元 純吃沙拉吧 非常超值', '', '', '2023-04-03'),
(9, 15, 17, 5, 5, '今天去用餐的感受是⋯⋯餐點普普的，沒有很有特色，吃粗飽的可以，如果要吃精緻的這裡比較不適合，餐點選擇性不多，可是有比別家好一些，不過主餐的豬排好乾好澀，完全不想吃，吃一片完就請服務人員收走，這裡有收一成服務費的，假日用餐只有100分鐘', '', '超難停車', '2023-03-15'),
(10, 39, 8, 4, 4, '面試完時間很尷尬，很接近下午茶感覺有快結束，從樹林繞到龜山萬壽路，又騎到新莊公園一路，看到貴族世家，好像以前有吃過板橋雙十路的店、也吃過萬壽路在迴龍店，這次來吃看看體育館店吧！至少有營業…\r\n點了厚切牛排，超多筋這肉訓練牙齒嗎？超多油又多筋，算了不計較，就浪費的吃…我只能說牛排比安格士好吃，只是熟食料理也是讓我好翻白眼，厚豆干、海帶、毛豆、太多很便宜的食物，感覺黑白切的料，再來是熟食我看了所有，我只搖桂竹筍（好便宜貨的嘴)、麵包、水果、挫冰、冰淇淋、可以用夾子點的，我點了蝦捲只給一條、剝皮雞湯、燙花椰菜、薑絲蛤蠣…我喝過同一家好吃的…無言誰叫自己時間不上不下的。花了572元感覺沒有高cp值，只能說不對我的味道。\r\n但喜歡吃到飽，不選擇食材的朋友可以吃吃。', '', '', '2024-01-22'),
(11, 3, 9, 4, 5, '很久沒有吃到雞吃飯入口時，雞汁香氣衝出於口中，飯粒軟卻不爛。這次點的煙燻雞肉，口感紮實，適合喜歡有咬勁的雞肉。溏心蛋細密入味。湯品用傳統陶器承裝，保溫效果很好。\r\n店家貼心地準備籃子裝雞骨頭，不會弄得到處都是，是很少見的細節。能夠看見店家的用心，推推～', '', '附近有計時停車場', '2023-05-25'),
(12, 1, 7, 2, 4, '第一次來吃這間 感覺不錯吃\r\n實際上吃了米心沒有熟的飯 反應了2次被店員白眼了感覺真差\r\n真的是一顆星都不想給 …', '', '', '2023-10-19'),
(13, 21, 8, 4, 2, '外帶這樣賣255有沒有搞錯 我到山上抓一隻雞都沒這麼扯= =我還再三確認好幾次到底有沒有漏掉 結果還真的只有六塊肉 太猛了 真的花錢買經驗', '', '', '2023-02-12'),
(14, 22, 7, 4, 4, '雞油飯很香，鹹中帶甜，飯粒Q彈。\r\n煙燻雞腿香氣十足，有肉汁、不柴、嫩，是好吃的土雞腿。我選的是泰式醬料，夠辣、夠酸、夠泰，讓土雞腿吃起來完全不會膩，但是，還蠻辣的，不吃辣的朋友不要點。\r\n溏心蛋，中規中矩，優點是能沾醬，更添風味。\r\n湯，蠻驚豔的，好喝，感覺是食材好，才煮出這種味道，可惜忘記拍照了。\r\n缺點，漬物的量也太少了點...\r\n整體來說，很讚，會再訪。', '', '', '2020-10-19'),
(15, 1, 27, 2, 1, '吃飯的過程腳下出現一直超大蟑螂，真噁心，最後那大蟑螂泡到花瓶裏面睡覺。\r\n金燻定食 300元就被這大蟑螂搞得心情不好。', '', '附近有計時停車場', '2023-02-27'),
(16, 8, 30, 4, 3, '因為凌晨真的找不到東西所以大家都來了\r\n早上三點半一樣超級多人\r\n店家快忙不過來沒時間理客人\r\n點餐要先去桌子拿紙自己寫之後會有人來收\r\n餐都是一個菜色全部桌同時發下去\r\n所以如果工作人員經過是在發你有點的\r\n舉手大叫就對了\r\n晚上在這裡是吃個氛圍 味道就普普通通啦', '松露牛肉堡, 鹽烤薯條 墨式肉醬, 錫蘭紅茶', '附近有計時停車場', '2021-02-21'),
(17, 25, 14, 5, 3, '炒蛤蜊都是殻\r\n菜都普普\r\n但點菜方式很特別，寫好數量店家會一次炒\r\n店家沒有先來後到的問題，先喊先贏，攻略是盡量坐在炒爐旁邊的位置，喊菜時要大聲，手要舉直，好似舉手跟老師說你要上廁所那樣洪亮！端菜的很猛，都一次端9盤，很有趣的體驗～', '黃金蘿蔔糕, 金錢蝦餅', '', '2021-04-30'),
(18, 18, 35, 2, 3, '個人覺得餐點還有很大的進步空間!\r\n\r\n號稱現點現做的料理，蝦捲、魚排卻都是冷的，薑絲蚵蠣湯有臭味不新鮮，楊枝甘露寡淡，西米露很糊爛。\r\n檯面上的菜式不多，熟食區保溫效果不佳，很快就冷掉了。飲料也很淡。', '', '', '2024-01-25'),
(19, 8, 20, 5, 4, '令人敬佩的好芳鄰—菲斯特，憶起在疫情時開幕，起初賣的餐點較簡單，挺過疫情，佳餚升級成華麗且更味美；小編K在同仁的推薦下，變成忠實主顧，今年第三次造訪，一樣大推冰淇淋披薩，甜滋滋的好味令人充滿幸福感😍感謝上天賜君悅就近品嚐好滋味的方便', '水牛城雞翅烤', '', '2022-09-12'),
(20, 9, 29, 4, 3, '隱藏在工業區的泰國料理\r\n用餐時間就只能登記在門口等待\r\n建議提早打電話留位子才不會這麼累\r\n吃服務態度那套的客人不要太玻璃心\r\n請迴避 姐姐們都不會太客氣的應答\r\n店員雖然多 因為客人太多都很忙\r\n但是只是口氣上的問題 其實都還是很好的對話\r\n\r\n炒粿條鹹香軟Q稍油了一點\r\n打拋雞肉吃起來很像涼拌雞絲拌飯\r\n月亮蝦餅厚實有咬勁\r\n酸辣湯蝦子花枝給的很多\r\n價錢也不貴，都是百元價錢', '滷豬腳, 鹹酥雞', '', '2021-12-21'),
(21, 18, 10, 5, 4, '炒飯、乾炒粄條、泰式炒河粉、蝦醬空心菜味道不錯，但豬肉片、雞胸都蠻乾的。\r\n小孩抱怨為何上次內用炒飯有附小黃瓜，外帶卻沒有？\r\n有次打電話要去訂幾天以後的位置，接電話的婦人講台語，說中午忙碌，要下午再打來，直接去餐廳了，她又說現在忙，晚點再打電話來，可是她在櫃檯看起來真的不忙（也沒人在結帳），她可能怕老闆生意太好了，幫老闆過濾掉一些客人！', '', '', '2023-07-01'),
(22, 20, 15, 5, 5, '餐點味道都還滿泰的，蝦餅厚實好吃！椒麻雞我個人沒有很喜歡。生蝦有辣但是辣得很讚！涼拌海鮮也是。泰奶也很好喝！價格都還算親民，推薦！可以先電話預訂', '', '附近有計時停車場', '2020-04-11'),
(23, 21, 16, 5, 4, '五星 味道非常的泰\r\n\r\n點了七道菜跟泰式奶茶，除了月亮蝦餅本人不是泰國菜，所以是真的不好吃之外，其他菜的口味都很棒，酸辣重口味，同行友人是泰國旅遊的狂熱者，說很不錯，冬陰功好喝，檸檬魚很便宜，但略有點土味，會擔心的可以避開，放開來吃到超飽還是很便宜，推推', '', '', '2021-02-25'),
(24, 39, 37, 3, 4, '以為是還有韓式燒烤去現場才發現只剩火鍋類，還有食材蔬菜、火鍋料、肉類，泡麵多種還有蛋🥚、牛肉丼飯，飲料，冰品吃較不好吃而已，沒有海鮮類，這些吃到飽價位算普通也沒有算一成服務費，服務人員妹妹都很不錯👍', '', '', '2023-11-29'),
(25, 3, 3, 4, 1, '以為是還有韓式燒烤去現場才發現只剩火鍋類，還有食材蔬菜、火鍋料、肉類，泡麵多種還有蛋🥚、牛肉丼飯，飲料，冰品吃較不好吃而已，沒有海鮮類，這些吃到飽價位算普通也沒有算一成服務費，服務人員妹妹都很不錯👍', '', '', '2023-05-12'),
(26, 9, 7, 4, 5, '以為是還有韓式燒烤去現場才發現只剩火鍋類，還有食材蔬菜、火鍋料、肉類，泡麵多種還有蛋🥚、牛肉丼飯，飲料，冰品吃較不好吃而已，沒有海鮮類，這些吃到飽價位算普通也沒有算一成服務費，服務人員妹妹都很不錯👍', '', '', '2024-01-14'),
(27, 3, 18, 4, 3, '吃到飽的火鍋，價格合理，肉品跟青菜的種類都蠻多的，吃起來也蠻新鮮的。生日還有送肉蛋糕很可愛。服務不錯，CP值高，推推！', '', '', '2022-07-24'),
(28, 21, 23, 2, 5, '吃到飽的火鍋，價格合理，肉品跟青菜的種類都蠻多的，吃起來也蠻新鮮的。生日還有送肉蛋糕很可愛。服務不錯，CP值高，推推！', '', '', '2022-08-26'),
(29, 36, 6, 5, 2, '吃到飽的火鍋，價格合理，肉品跟青菜的種類都蠻多的，吃起來也蠻新鮮的。生日還有送肉蛋糕很可愛。服務不錯，CP值高，推推！', '', '', '2022-04-01'),
(30, 2, 15, 1, 4, '吃到飽的火鍋，價格合理，肉品跟青菜的種類都蠻多的，吃起來也蠻新鮮的。生日還有送肉蛋糕很可愛。服務不錯，CP值高，推推！', '', '', '2022-02-18'),
(31, 33, 29, 1, 3, '東西變少了😓😓，\r\n炸物~~真的不行，冷冷的、皮硬硬的；\r\n天氣🥶冷，冷菜一堆，感覺很不合適；\r\n🐷 腳軟嫩，🦈 肉還不錯！\r\n楊枝甘露 😍😍 不錯喝，可惜用 味增湯碗裝，徹底讓 美味 扣分；\r\n🍰 選擇還算多，不算特別，有的還 乾乾的😓😓。\r\n只能說，CP 值弱掉了，如果能打掉重練，就不會浪費 店的優勢。😁😁', '酥皮濃湯, 薑絲蛤蜊湯', '有停車場', '2023-05-15');

-- --------------------------------------------------------

--
-- 資料表結構 `comment_image`
--

CREATE TABLE `comment_image` (
  `image_id` int(30) NOT NULL,
  `name` varchar(100) NOT NULL,
  `comment_id` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `comment_image`
--

INSERT INTO `comment_image` (`image_id`, `name`, `comment_id`) VALUES
(1, '評論照01.png', 5),
(2, '評論照02.png', 5),
(3, '評論照03.png', 5),
(4, '評論照04.png\r\n', 2),
(5, '評論照05.png', 2),
(6, '評論照06.png', 2),
(7, '評論照07.png', 2),
(8, '評論照08.png', 20),
(9, '評論照09.png', 26),
(10, '評論照10.png', 26),
(11, '評論照11.png', 26);

-- --------------------------------------------------------

--
-- 資料表結構 `good`
--

CREATE TABLE `good` (
  `good_id` int(30) NOT NULL,
  `custom_Id` int(30) NOT NULL,
  `comment_id` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `good`
--

INSERT INTO `good` (`good_id`, `custom_Id`, `comment_id`) VALUES
(1, 1, 11),
(2, 20, 17),
(3, 1, 12),
(4, 29, 12),
(5, 29, 5),
(6, 29, 13),
(7, 22, 13),
(8, 13, 17),
(9, 27, 20);

-- --------------------------------------------------------

--
-- 資料表結構 `sub_comment`
--

CREATE TABLE `sub_comment` (
  `sub_id` int(30) NOT NULL,
  `merchant_id` int(30) NOT NULL,
  `comment_id` int(30) NOT NULL,
  `content` varchar(100) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `sub_comment`
--

INSERT INTO `sub_comment` (`sub_id`, `merchant_id`, `comment_id`, `content`, `date`) VALUES
(1, 7, 14, '謝謝您喜歡春秋的服務，期待您的再度光臨^^', '2020-11-15'),
(2, 27, 15, '不好意思照成妳的不愉快\r\n當日已告知店員並加強人員服務訓練\r\n萬分真誠的向妳道歉', '2023-02-28'),
(3, 9, 2, '謝謝您的蒞臨與喜愛，全體同仁十分榮幸能為您創造如此愉悅的體驗，並竭誠期待很快能再為您服務～', '2023-08-29'),
(4, 7, 12, '謝謝您喜歡春秋的服務，期待您的再度光臨^^', '2023-10-20'),
(5, 9, 11, '謝謝您的蒞臨與喜愛，全體同仁十分榮幸能為您創造如此愉悅的體驗，並竭誠期待很快能再為您服務～', '2023-05-25'),
(6, 10, 21, '謝謝您的蒞臨與喜愛', '2023-07-02');

--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `ad_auto_close`
--
ALTER TABLE `ad_auto_close`
  ADD KEY `record_id` (`record_id`),
  ADD KEY `ad_id` (`ad_id`);

--
-- 資料表索引 `ad_price`
--
ALTER TABLE `ad_price`
  ADD PRIMARY KEY (`ad_id`) USING BTREE;

--
-- 資料表索引 `ad_record`
--
ALTER TABLE `ad_record`
  ADD PRIMARY KEY (`record_id`),
  ADD KEY `ad_id` (`ad_id`);

--
-- 資料表索引 `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`comment_id`);

--
-- 資料表索引 `comment_image`
--
ALTER TABLE `comment_image`
  ADD PRIMARY KEY (`image_id`),
  ADD KEY `comment_id` (`comment_id`);

--
-- 資料表索引 `good`
--
ALTER TABLE `good`
  ADD PRIMARY KEY (`good_id`),
  ADD KEY `comment_id` (`comment_id`);

--
-- 資料表索引 `sub_comment`
--
ALTER TABLE `sub_comment`
  ADD PRIMARY KEY (`sub_id`),
  ADD KEY `comment_id` (`comment_id`);

--
-- 在傾印的資料表使用自動遞增(AUTO_INCREMENT)
--

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `ad_record`
--
ALTER TABLE `ad_record`
  MODIFY `record_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `comment`
--
ALTER TABLE `comment`
  MODIFY `comment_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `comment_image`
--
ALTER TABLE `comment_image`
  MODIFY `image_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `good`
--
ALTER TABLE `good`
  MODIFY `good_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `sub_comment`
--
ALTER TABLE `sub_comment`
  MODIFY `sub_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- 已傾印資料表的限制式
--

--
-- 資料表的限制式 `ad_auto_close`
--
ALTER TABLE `ad_auto_close`
  ADD CONSTRAINT `ad_auto_close_ibfk_1` FOREIGN KEY (`record_id`) REFERENCES `ad_record` (`record_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ad_auto_close_ibfk_2` FOREIGN KEY (`ad_id`) REFERENCES `ad_price` (`ad_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 資料表的限制式 `ad_record`
--
ALTER TABLE `ad_record`
  ADD CONSTRAINT `ad_record_ibfk_1` FOREIGN KEY (`ad_id`) REFERENCES `ad_price` (`ad_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 資料表的限制式 `comment_image`
--
ALTER TABLE `comment_image`
  ADD CONSTRAINT `comment_image_ibfk_1` FOREIGN KEY (`comment_id`) REFERENCES `comment` (`comment_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 資料表的限制式 `good`
--
ALTER TABLE `good`
  ADD CONSTRAINT `good_ibfk_1` FOREIGN KEY (`comment_id`) REFERENCES `comment` (`comment_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 資料表的限制式 `sub_comment`
--
ALTER TABLE `sub_comment`
  ADD CONSTRAINT `sub_comment_ibfk_1` FOREIGN KEY (`comment_id`) REFERENCES `comment` (`comment_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
