<?php
// 导入数据库连接
require __DIR__ . '/components/connectToSql.php';
?>

<?php include __DIR__ . "/components/head.php"; ?>
<style>
    form .mb-3 .form-text {
        color: red;
    }

    .is-invalid {
        border: 1px solid red;
    }

    #timeError {
        color: red;
    }
</style>

<div class="container mt-3">
    <h2>新增賣家資料</h2>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form name="form1" method="post" onsubmit="sendForm(event)" enctype="multipart/form-data">
                        <!-- 在这里添加表单输入框，根据需要调整 -->
                        <div class="mb-3">
                            <label for="name" class="form-label">攤位名稱</label>
                            <input type="text" class="form-control" id="name" name="name" placeholder="攤位名稱">
                            <div class="form-text">該欄位必填</div>
                        </div>

                        <div class="mb-3">
                            <label for="company_name" class="form-label">公司名稱</label>
                            <input type="text" class="form-control" id="company_name" name="company_name" placeholder="公司名稱">
                            <div class="form-text">該欄位必填</div>
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">電子信箱</label>
                            <input type="text" class="form-control" id="email" name="email" placeholder="電子信箱">
                            <div class="form-text">該欄位必填，且必須符合正確的電子郵件格式</div>
                        </div>

                        <div class="mb-3">
                            <label for="address" class="form-label">攤位地址</label>
                            <input type="text" class="form-control" id="address" name="address" placeholder="攤位地址">
                            <div class="form-text">該欄位必填</div>
                        </div>

                        <div class="mb-3">
                            <label for="profile_picture" class="form-label">上傳圖片</label>
                            <input type="file" class="form-control" id="profile_picture" name="image">
                            <div class="form-text">該欄位必填</div>
                        </div>

                        <div class="mb-3">
                            <label for="introduction" class="form-label">攤位簡介</label>
                            <textarea class="form-control" id="introduction" name="introduction" rows="3" placeholder="攤位簡介"></textarea>
                            <div class="form-text">該欄位必填</div>
                        </div>

                        <div class="mb-3">
                            <label for="phone" class="form-label">連絡電話</label>
                            <input type="text" class="form-control" id="phone" name="phone" placeholder="連絡電話">
                            <div class="form-text">該欄位必填，且必須符合正確的電話號碼格式</div>
                        </div>

                        <div class="business-hours-container">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="select-container">
                                        <label for="business_hours_start">開始時間：</label>
                                        <select name="business_hours_start" id="business_hours_start">
                                            <?php
                                            // 產生 24 小時的選項
                                            for ($i = 0; $i < 24; $i++) {
                                                $startHour = sprintf("%02d", $i);
                                                echo "<option value='$startHour'>$startHour:00</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="select-container">
                                        <label for="business_hours_end">結束時間：</label>
                                        <select name="business_hours_end" id="business_hours_end">
                                            <?php
                                            // 產生 24 小時的選項
                                            for ($i = 0; $i < 24; $i++) {
                                                $endHour = sprintf("%02d", $i);
                                                echo "<option value='$endHour'>$endHour:00</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div id="timeError" class="form-text"></div>
                        </div>

                        <div class="d-flex justify-content-between">
                            <div>
                                <button type="submit" class="btn btn-primary">新增資料</button>
                            </div>

                            <div class="mt-1">
                                <a href="list.php">回到產品列表</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function sendForm(event) {
        event.preventDefault(); // 阻止表單提交
        const formData = new FormData(document.forms.form1);

        function validateForm() {
            let isValid = true;

            document.querySelectorAll('.form-control').forEach(input => {
                input.classList.remove('is-invalid');
            });
            document.querySelectorAll('.form-text').forEach(errorMsg => {
                errorMsg.innerText = '';
            });

            // 添加額外的驗證邏輯
            if (!formData.get('name') || (formData.get('name') && formData.get('name').trim() === '')) {
                document.forms.form1.name.classList.add('is-invalid');
                document.forms.form1.name.nextElementSibling.innerText = '該欄位必填';
                isValid = false;
            }
            if (!formData.get('company_name') || formData.get('company_name').trim() === '') {
                document.forms.form1.company_name.classList.add('is-invalid');
                document.forms.form1.company_name.nextElementSibling.innerText = '該欄位必填';
                isValid = false;
            }
            if (!formData.get('email') || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.get('email').trim())) {
                document.forms.form1.email.classList.add('is-invalid');
                document.forms.form1.email.nextElementSibling.innerText = '該欄位必填，且必須符合正確的電子郵件格式';
                isValid = false;
            }
            if (!formData.get('address') || formData.get('address').trim() === '') {
                document.forms.form1.address.classList.add('is-invalid');
                document.forms.form1.address.nextElementSibling.innerText = '該欄位必填';
                isValid = false;
            }
            if (!formData.get('image')) {
                document.forms.form1.image.classList.add('is-invalid');
                document.forms.form1.image.nextElementSibling.innerText = '該欄位必填';
                isValid = false;
            }
            if (!formData.get('introduction') || formData.get('introduction').trim() === '') {
                document.forms.form1.introduction.classList.add('is-invalid');
                document.forms.form1.introduction.nextElementSibling.innerText = '該欄位必填';
                isValid = false;
            }
            if (!formData.get('phone') || !/^\d{10}$/.test(formData.get('phone').trim())) {
                document.forms.form1.phone.classList.add('is-invalid');
                document.forms.form1.phone.nextElementSibling.innerText = '該欄位必填，且必須符合正確的電話號碼格式';
                isValid = false;
            }

            const startHour = parseInt(formData.get('business_hours_start'), 10);
            const endHour = parseInt(formData.get('business_hours_end'), 10);

            if (startHour >= endHour) {
                document.getElementById('timeError').innerText = '開始營業時間必須比結束營業時間早';
                isValid = false;
            }

            return isValid;
        }

        // 添加 fetch 到 validateForm 內
        if (validateForm()) {
            // 使用 fetch 進行提交
            fetch('add-api.php', {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    // 處理伺服器返回的數據
                    if (data.success) {
                        // 添加成功，重定向或執行其他操作
                        window.location.href = data.redirect;
                    } else {
                        // 添加失敗，處理錯誤信息
                        console.error(data.error);
                    }
                })
                .catch(error => {
                    console.error('Error during fetch:', error);
                });
        }
    }
</script>

<?php include __DIR__ . "/components/scripts.php"; ?>
