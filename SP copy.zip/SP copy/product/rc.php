<?php
// 導入資料庫連線
require __DIR__. '/components/connectToSql.php';

$records_per_page = 3;
$pageName = "list";
$title = "列表";

// 獲取當前頁碼
if (isset($_GET['page']) && is_numeric($_GET['page'])) {
    $current_page = (int)$_GET['page'];
} else {
    $current_page = 1;
}

// 處理搜尋
$search_name = '';
if (isset($_GET['search_name']) && !empty($_GET['search_name'])) {
    $search_name = $_GET['search_name'];
    $sql = "SELECT * FROM sellers WHERE name LIKE :search_name";
} else {
    $sql = "SELECT * FROM sellers";
}

// 獲取總數據數
$total_records = $pdo->prepare($sql);
if (!empty($search_name)) {
    $search_name = '%' . $search_name . '%'; 
    $total_records->bindParam(':search_name', $search_name, PDO::PARAM_STR);
}
$total_records->execute();
$total_records = $total_records->rowCount();

// 計算總頁數
$total_pages = ceil($total_records / $records_per_page);

// 計算 OFFSET
$offset = ($current_page - 1) * $records_per_page;

$sql .= " LIMIT :offset, :records_per_page";

// 執行查詢
$stmt = $pdo->prepare($sql);
if (!empty($search_name)) {
    $stmt->bindParam(':search_name', $search_name, PDO::PARAM_STR);
}
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->bindValue(':records_per_page', $records_per_page, PDO::PARAM_INT);
$stmt->execute();

// 獲取結果
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<?php include __DIR__ . "/components/head.php" ?>

<div class="container mt-3">

<!-- Bootstrap 表格 -->
<div class="container">
    <h2>商家資料</h2>
    <!-- 搜尋欄表單 -->
    <form method="get" class="mb-3">
        <div class="input-group input-group-sm">
            <input type="text" class="form-control form-control-sm" id="search_name" name="search_name" value="<?php echo htmlspecialchars(trim($search_name, '%')); ?>">
            <button type="submit" class="btn btn-primary">搜尋攤位</button>
        </div>
    </form>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>刪除資料</th> 
                <th>賣家ID</th>
                <th>攤位名子</th>
                <th>公司名稱</th>
                <th>電子信箱</th>
                <th>攤位地址</th>
                <th>圖片</th>
                <th>攤位簡介</th>
                <th>連絡電話</th>
                <th>營業時間</th> 
            </tr>
        </thead>
        <tbody>
            <?php foreach ($rows as $row): ?>
                <tr>
                    <td>
                        <a href="delete-api.php?seller_id=<?php echo $row['seller_id']; ?>" onclick="return confirm('確定要刪除這條資料嗎？');">
                            <i class="fa-solid fa-trash"></i>
                        </a>
                    </td>
                    <td><?php echo $row['seller_id']; ?></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['company_name']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php echo htmlentities($row['address']) ?></td>
                    <td><?php echo $row['profile_picture']; ?></td>
                    <td><?php echo $row['introduction']; ?></td>
                    <td><?php echo $row['phone']; ?></td>
                    <td><?php echo $row['business_hours']; ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <!-- 分頁 -->
    <ul class="pagination">
        <?php if ($current_page > 1): ?>
            <li class="page-item">
                <a class="page-link" href="?page=<?php echo $current_page - 1; ?>" aria-label="Previous">
                    <i class="fa-solid fa-angles-left"></i>
                </a>
            </li>
            <li class="page-item">
                <a class="page-link" href="?page=1">
                    <i class="fa-solid fa-angle-left"></i>
                </a>
            </li>
        <?php endif; ?>

        <?php for ($i = max(1, $current_page - 2); $i <= min($current_page + 2, $total_pages); $i++): ?>
            <li class="page-item <?php echo ($i === $current_page) ? 'active' : ''; ?>">
                <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
            </li>
        <?php endfor; ?>

        <?php if ($current_page < $total_pages): ?>
            <li class="page-item">
                <a class="page-link" href="?page=<?php echo $current_page + 1; ?>" aria-label="Next">
                    <i class="fa-solid fa-angle-right"></i>
                </a>
            </li>
            <li class="page-item">
                <a class="page-link" href="?page=<?php echo $total_pages; ?>">
                    <i class="fa-solid fa-angles-right"></i>
                </a>
            </li>
        <?php endif; ?>
    </ul>

</div>
