-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- 主機： 127.0.0.1
-- 產生時間： 2024-01-22 14:20:30
-- 伺服器版本： 10.4.32-MariaDB
-- PHP 版本： 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `night_snack`
--

DELIMITER $$
--
-- 程序
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertTestSellerData` ()   BEGIN
    DECLARE counter INT DEFAULT 0;

    WHILE counter < 100 DO
        INSERT INTO sellers (name, company_name, email, address, profile_picture, introduction, phone)
        VALUES
        (CONCAT('測試用戶', counter + 1), 
         CONCAT('公司', counter + 1),
         CONCAT('test', counter + 1, '@example.com'), 
         CONCAT('地址', counter + 1),
         CONCAT('profile', counter % 5 + 1, '.jpg'),
         CONCAT('自我介紹', counter + 1),
         CONCAT('091234', LPAD(counter % 1000, 4, '0')));

        SET counter = counter + 1;
    END WHILE;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- 資料表結構 `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `category` varchar(255) DEFAULT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_description` text DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock_quantity` int(11) NOT NULL,
  `listing_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(50) NOT NULL,
  `seller_id` int(11) DEFAULT NULL,
  `points_price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `products`
--

INSERT INTO `products` (`product_id`, `category`, `product_name`, `product_description`, `image_url`, `price`, `stock_quantity`, `listing_date`, `status`, `seller_id`, `points_price`) VALUES
(1, '點心', '可麗餅', '酥脆可口的可麗餅', 'crepe_image.jpg', 5.99, 50, '2024-01-20 16:00:00', '上架中', 1, 60),
(2, '飲料', '珍珠奶茶', '香濃奶茶搭配Q彈珍珠', 'bubble_tea_image.jpg', 4.99, 80, '2024-01-20 16:00:00', '上架中', 1, 55),
(3, '小吃', '雞排', '酥脆美味的雞排', 'chicken_cutlet_image.jpg', 6.99, 60, '2024-01-20 16:00:00', '上架中', 1, 70),
(4, '飲料', '木瓜牛奶', '香濃牛奶搭配新鮮木瓜', 'papaya_milk_image.jpg', 5.49, 75, '2024-01-20 16:00:00', '上架中', 1, 60),
(5, '小吃', '蚵仔煎', '酥脆美味的台灣小吃', 'oyster_omelette_image.jpg', 8.99, 40, '2024-01-20 16:00:00', '上架中', 1, 80),
(6, '主食', '火雞肉飯', '美味的火雞肉搭配香噴噴的白飯', 'turkey_rice_image.jpg', 7.49, 55, '2024-01-20 16:00:00', '上架中', 1, 65),
(7, '主食', '鱔魚意麵', '美味的鱔魚搭配暖呼呼的意麵', 'eel_pasta_image.jpg', 9.99, 30, '2024-01-20 16:00:00', '上架中', 1, 90),
(8, '小吃', '棺材板', '多種配料的美味烤吐司', 'mixed_toast_image.jpg', 6.49, 45, '2024-01-20 16:00:00', '上架中', 1, 70),
(9, '小吃', '潤餅', '台灣傳統美食，薄餅包裹豐富的內餡', 'thin_pancake_image.jpg', 5.99, 65, '2024-01-20 16:00:00', '上架中', 1, 60),
(10, '點心', '車輪餅', '外酥內軟的台灣傳統點心', 'wheel_cake_image.jpg', 4.99, 55, '2024-01-20 16:00:00', '上架中', 1, 50),
(11, '點心', '筒仔米糕', '傳統台灣米糕，美味可口', 'tube_rice_cake_image.jpg', 3.99, 70, '2024-01-20 16:00:00', '上架中', 1, 40),
(12, '點心', '黑糖糕', '香甜可口的黑糖糕點心', 'brown_sugar_cake_image.jpg', 4.49, 60, '2024-01-20 16:00:00', '上架中', 1, 45),
(13, '主食', '滷肉飯', '美味的滷肉飯，香氣四溢', 'braised_pork_rice_image.jpg', 6.99, 50, '2024-01-20 16:00:00', '上架中', 1, 70),
(14, '湯品', '土魠魚羹', '清爽美味的土魠魚羹湯品', 'fish_soup_image.jpg', 5.99, 40, '2024-01-20 16:00:00', '上架中', 1, 55),
(15, '小吃', '刈包', '台灣傳統美味小吃，虎咬豬，多種配料搭配口感獨特的麵皮', 'gua_bao_image.jpg', 7.49, 45, '2024-01-20 16:00:00', '上架中', 1, 75),
(16, '點心', '小籠包', '鮮美的小籠包，湯汁豐富', 'xiaolongbao_image.jpg', 8.99, 35, '2024-01-20 16:00:00', '上架中', 1, 85),
(17, '小吃', '大腸包小腸', '像熱狗般的「雙腸」組合，讓你每一口都充滿驚奇', 'sausage_in_large_intestine_image.jpg', 6.49, 50, '2024-01-20 16:00:00', '上架中', 1, 65),
(18, '小吃', '臭豆腐', '風靡夜市的台灣特色小吃，炸到金黃香酥的臭豆腐，淋上帶有甜味的蒜蓉醬再搭泡菜後爆表好吃', 'stinky_tofu_image.jpg', 5.99, 40, '2024-01-20 16:00:00', '上架中', 1, 55),
(19, '甜品', '豆花', '清涼爽口，入口即化的豆花 ', 'tofu_pudding_image.jpg', 4.49, 60, '2024-01-20 16:00:00', '上架中', 1, 45),
(20, '主食', '鹽酥雞', '雞肉外脆內嫩的鮮嫩口感，加上獨特的香料調味和配方使每一口都充滿風味，更有九層塔、生蒜碎等，一口咬下鹹香夠味的好滋味，加上多層次的調味，讓人一吃就著迷，忍不住一口接著一口吃不停。', 'popcorn_chicken_image.jpg', 6.99, 50, '2024-01-20 16:00:00', '上架中', 1, 70),
(21, '點心', '地瓜球', '甜蜜美味的地瓜球點心', 'sweet_potato_balls_image.jpg', 4.49, 60, '2024-01-20 16:00:00', '上架中', 1, 45),
(22, '點心', '白糖粿', '由糯米糰製成的白糖粿，油炸過後，熱熱的沾上白糖、花生粉吃，外酥內軟非常好吃', 'white_sugar_cake_image.jpg', 5.49, 55, '2024-01-20 16:00:00', '上架中', 1, 50),
(23, '主食', '營養三明治', '炸得金黃酥脆的麵包，配上滷蛋、火腿、黃瓜、番茄等內餡，再擠上重頭戲、濃郁的美乃滋，一口咬下，唇齒留香', 'nutritious_sandwich_image.jpg', 7.99, 40, '2024-01-20 16:00:00', '上架中', 1, 80),
(24, '主食', '天婦羅', '日式炸物，外酥內嫩', 'tempura_image.jpg', 8.49, 35, '2024-01-20 16:00:00', '上架中', 1, 85),
(25, '湯品', '肉羹湯', '滑順的羹湯搭配各種脆口的食材，肉條經過香辛料、金黃蒜油裹粉醃漬燙過，口感軟嫩、蒜味濃郁，濃郁的香菇風味使柴魚湯底層次更濃厚豐富！每一口都是滿滿的台灣味', 'meat_soup_image.jpg', 6.49, 45, '2024-01-20 16:00:00', '上架中', 1, 65),
(26, '主食', '夜市牛排', '入口即化的牛肉、現炒鐵板麵淋上蘑菇醬、佐營養三色豆，加上一顆生雞蛋，半熟吃實在美味', 'night_market_steak_image.jpg', 12.99, 30, '2024-01-20 16:00:00', '上架中', 1, 120),
(27, '甜品', '糖葫蘆', '番茄、草莓等食材，外成裹上一層糖衣，吃起來酸甜可口', 'candied_haw_image.jpg', 3.99, 70, '2024-01-20 16:00:00', '上架中', 1, 35),
(28, '小吃', '蔥油餅', '青蔥香氣四溢，配上酥脆有嚼勁的金黃色的餅皮', 'scallion_pancake_image.jpg', 5.49, 55, '2024-01-20 16:00:00', '上架中', 1, 50),
(29, '湯品', '蚵仔麵線', '鮮美的蚵仔配上細緻的麵線湯', 'oyster_mee_sua_image.jpg', 7.49, 40, '2024-01-20 16:00:00', '上架中', 1, 75),
(30, '甜品', '芒果冰', '新鮮芒果搭配豐富配料的冰品', 'mango_ice_image.jpg', 6.99, 50, '2024-01-20 16:00:00', '上架中', 1, 65);

-- --------------------------------------------------------

--
-- 資料表結構 `sellers`
--

CREATE TABLE `sellers` (
  `seller_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `address` text DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `introduction` text DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `sellers`
--

INSERT INTO `sellers` (`seller_id`, `name`, `company_name`, `email`, `address`, `profile_picture`, `introduction`, `phone`) VALUES
(1, '王大明', '美食天地', 'wang@example.com', '台北市中山區中山北路123號', 'profile1.jpg', '我們提供各種美味小吃！', '0912345678'),
(2, '林小華', '夜市小吃屋', 'lin@example.com', '新北市板橋區民生路456號', 'profile2.jpg', '專業夜市小吃，保證讓您滿意！', '0987654321'),
(3, '測試用戶1', '公司1', 'test1@example.com', '地址1', 'profile1.jpg', '自我介紹1', '09123450000'),
(4, '測試用戶2', '公司2', 'test2@example.com', '地址2', 'profile2.jpg', '自我介紹2', '09123450001'),
(5, '測試用戶3', '公司3', 'test3@example.com', '地址3', 'profile3.jpg', '自我介紹3', '09123450002'),
(6, '測試用戶4', '公司4', 'test4@example.com', '地址4', 'profile4.jpg', '自我介紹4', '09123450003'),
(7, '測試用戶5', '公司5', 'test5@example.com', '地址5', 'profile5.jpg', '自我介紹5', '09123450004'),
(8, '測試用戶6', '公司6', 'test6@example.com', '地址6', 'profile1.jpg', '自我介紹6', '09123450005'),
(9, '測試用戶7', '公司7', 'test7@example.com', '地址7', 'profile2.jpg', '自我介紹7', '09123450006'),
(10, '測試用戶8', '公司8', 'test8@example.com', '地址8', 'profile3.jpg', '自我介紹8', '09123450007'),
(11, '測試用戶9', '公司9', 'test9@example.com', '地址9', 'profile4.jpg', '自我介紹9', '09123450008'),
(12, '測試用戶10', '公司10', 'test10@example.com', '地址10', 'profile5.jpg', '自我介紹10', '09123450009'),
(13, '測試用戶11', '公司11', 'test11@example.com', '地址11', 'profile1.jpg', '自我介紹11', '09123450010'),
(14, '測試用戶12', '公司12', 'test12@example.com', '地址12', 'profile2.jpg', '自我介紹12', '09123450011'),
(15, '測試用戶13', '公司13', 'test13@example.com', '地址13', 'profile3.jpg', '自我介紹13', '09123450012'),
(16, '測試用戶14', '公司14', 'test14@example.com', '地址14', 'profile4.jpg', '自我介紹14', '09123450013'),
(17, '測試用戶15', '公司15', 'test15@example.com', '地址15', 'profile5.jpg', '自我介紹15', '09123450014'),
(18, '測試用戶16', '公司16', 'test16@example.com', '地址16', 'profile1.jpg', '自我介紹16', '09123450015'),
(19, '測試用戶17', '公司17', 'test17@example.com', '地址17', 'profile2.jpg', '自我介紹17', '09123450016'),
(20, '測試用戶18', '公司18', 'test18@example.com', '地址18', 'profile3.jpg', '自我介紹18', '09123450017'),
(21, '測試用戶19', '公司19', 'test19@example.com', '地址19', 'profile4.jpg', '自我介紹19', '09123450018'),
(22, '測試用戶20', '公司20', 'test20@example.com', '地址20', 'profile5.jpg', '自我介紹20', '09123450019'),
(23, '測試用戶21', '公司21', 'test21@example.com', '地址21', 'profile1.jpg', '自我介紹21', '09123450020'),
(24, '測試用戶22', '公司22', 'test22@example.com', '地址22', 'profile2.jpg', '自我介紹22', '09123450021'),
(25, '測試用戶23', '公司23', 'test23@example.com', '地址23', 'profile3.jpg', '自我介紹23', '09123450022'),
(26, '測試用戶24', '公司24', 'test24@example.com', '地址24', 'profile4.jpg', '自我介紹24', '09123450023'),
(27, '測試用戶25', '公司25', 'test25@example.com', '地址25', 'profile5.jpg', '自我介紹25', '09123450024'),
(28, '測試用戶26', '公司26', 'test26@example.com', '地址26', 'profile1.jpg', '自我介紹26', '09123450025'),
(29, '測試用戶27', '公司27', 'test27@example.com', '地址27', 'profile2.jpg', '自我介紹27', '09123450026'),
(30, '測試用戶28', '公司28', 'test28@example.com', '地址28', 'profile3.jpg', '自我介紹28', '09123450027'),
(31, '測試用戶29', '公司29', 'test29@example.com', '地址29', 'profile4.jpg', '自我介紹29', '09123450028'),
(32, '測試用戶30', '公司30', 'test30@example.com', '地址30', 'profile5.jpg', '自我介紹30', '09123450029'),
(33, '測試用戶31', '公司31', 'test31@example.com', '地址31', 'profile1.jpg', '自我介紹31', '09123450030'),
(34, '測試用戶32', '公司32', 'test32@example.com', '地址32', 'profile2.jpg', '自我介紹32', '09123450031'),
(35, '測試用戶33', '公司33', 'test33@example.com', '地址33', 'profile3.jpg', '自我介紹33', '09123450032'),
(36, '測試用戶34', '公司34', 'test34@example.com', '地址34', 'profile4.jpg', '自我介紹34', '09123450033'),
(37, '測試用戶35', '公司35', 'test35@example.com', '地址35', 'profile5.jpg', '自我介紹35', '09123450034'),
(38, '測試用戶36', '公司36', 'test36@example.com', '地址36', 'profile1.jpg', '自我介紹36', '09123450035'),
(39, '測試用戶37', '公司37', 'test37@example.com', '地址37', 'profile2.jpg', '自我介紹37', '09123450036'),
(40, '測試用戶38', '公司38', 'test38@example.com', '地址38', 'profile3.jpg', '自我介紹38', '09123450037'),
(41, '測試用戶39', '公司39', 'test39@example.com', '地址39', 'profile4.jpg', '自我介紹39', '09123450038'),
(42, '測試用戶40', '公司40', 'test40@example.com', '地址40', 'profile5.jpg', '自我介紹40', '09123450039'),
(43, '測試用戶41', '公司41', 'test41@example.com', '地址41', 'profile1.jpg', '自我介紹41', '09123450040'),
(44, '測試用戶42', '公司42', 'test42@example.com', '地址42', 'profile2.jpg', '自我介紹42', '09123450041'),
(45, '測試用戶43', '公司43', 'test43@example.com', '地址43', 'profile3.jpg', '自我介紹43', '09123450042'),
(46, '測試用戶44', '公司44', 'test44@example.com', '地址44', 'profile4.jpg', '自我介紹44', '09123450043'),
(47, '測試用戶45', '公司45', 'test45@example.com', '地址45', 'profile5.jpg', '自我介紹45', '09123450044'),
(48, '測試用戶46', '公司46', 'test46@example.com', '地址46', 'profile1.jpg', '自我介紹46', '09123450045'),
(49, '測試用戶47', '公司47', 'test47@example.com', '地址47', 'profile2.jpg', '自我介紹47', '09123450046'),
(50, '測試用戶48', '公司48', 'test48@example.com', '地址48', 'profile3.jpg', '自我介紹48', '09123450047'),
(51, '測試用戶49', '公司49', 'test49@example.com', '地址49', 'profile4.jpg', '自我介紹49', '09123450048'),
(52, '測試用戶50', '公司50', 'test50@example.com', '地址50', 'profile5.jpg', '自我介紹50', '09123450049'),
(53, '測試用戶51', '公司51', 'test51@example.com', '地址51', 'profile1.jpg', '自我介紹51', '09123450050'),
(54, '測試用戶52', '公司52', 'test52@example.com', '地址52', 'profile2.jpg', '自我介紹52', '09123450051'),
(55, '測試用戶53', '公司53', 'test53@example.com', '地址53', 'profile3.jpg', '自我介紹53', '09123450052'),
(56, '測試用戶54', '公司54', 'test54@example.com', '地址54', 'profile4.jpg', '自我介紹54', '09123450053'),
(57, '測試用戶55', '公司55', 'test55@example.com', '地址55', 'profile5.jpg', '自我介紹55', '09123450054'),
(58, '測試用戶56', '公司56', 'test56@example.com', '地址56', 'profile1.jpg', '自我介紹56', '09123450055'),
(59, '測試用戶57', '公司57', 'test57@example.com', '地址57', 'profile2.jpg', '自我介紹57', '09123450056'),
(60, '測試用戶58', '公司58', 'test58@example.com', '地址58', 'profile3.jpg', '自我介紹58', '09123450057'),
(61, '測試用戶59', '公司59', 'test59@example.com', '地址59', 'profile4.jpg', '自我介紹59', '09123450058'),
(62, '測試用戶60', '公司60', 'test60@example.com', '地址60', 'profile5.jpg', '自我介紹60', '09123450059'),
(63, '測試用戶61', '公司61', 'test61@example.com', '地址61', 'profile1.jpg', '自我介紹61', '09123450060'),
(64, '測試用戶62', '公司62', 'test62@example.com', '地址62', 'profile2.jpg', '自我介紹62', '09123450061'),
(65, '測試用戶63', '公司63', 'test63@example.com', '地址63', 'profile3.jpg', '自我介紹63', '09123450062'),
(66, '測試用戶64', '公司64', 'test64@example.com', '地址64', 'profile4.jpg', '自我介紹64', '09123450063'),
(67, '測試用戶65', '公司65', 'test65@example.com', '地址65', 'profile5.jpg', '自我介紹65', '09123450064'),
(68, '測試用戶66', '公司66', 'test66@example.com', '地址66', 'profile1.jpg', '自我介紹66', '09123450065'),
(69, '測試用戶67', '公司67', 'test67@example.com', '地址67', 'profile2.jpg', '自我介紹67', '09123450066'),
(70, '測試用戶68', '公司68', 'test68@example.com', '地址68', 'profile3.jpg', '自我介紹68', '09123450067'),
(71, '測試用戶69', '公司69', 'test69@example.com', '地址69', 'profile4.jpg', '自我介紹69', '09123450068'),
(72, '測試用戶70', '公司70', 'test70@example.com', '地址70', 'profile5.jpg', '自我介紹70', '09123450069'),
(73, '測試用戶71', '公司71', 'test71@example.com', '地址71', 'profile1.jpg', '自我介紹71', '09123450070'),
(74, '測試用戶72', '公司72', 'test72@example.com', '地址72', 'profile2.jpg', '自我介紹72', '09123450071'),
(75, '測試用戶73', '公司73', 'test73@example.com', '地址73', 'profile3.jpg', '自我介紹73', '09123450072'),
(76, '測試用戶74', '公司74', 'test74@example.com', '地址74', 'profile4.jpg', '自我介紹74', '09123450073'),
(77, '測試用戶75', '公司75', 'test75@example.com', '地址75', 'profile5.jpg', '自我介紹75', '09123450074'),
(78, '測試用戶76', '公司76', 'test76@example.com', '地址76', 'profile1.jpg', '自我介紹76', '09123450075'),
(79, '測試用戶77', '公司77', 'test77@example.com', '地址77', 'profile2.jpg', '自我介紹77', '09123450076'),
(80, '測試用戶78', '公司78', 'test78@example.com', '地址78', 'profile3.jpg', '自我介紹78', '09123450077'),
(81, '測試用戶79', '公司79', 'test79@example.com', '地址79', 'profile4.jpg', '自我介紹79', '09123450078'),
(82, '測試用戶80', '公司80', 'test80@example.com', '地址80', 'profile5.jpg', '自我介紹80', '09123450079'),
(83, '測試用戶81', '公司81', 'test81@example.com', '地址81', 'profile1.jpg', '自我介紹81', '09123450080'),
(84, '測試用戶82', '公司82', 'test82@example.com', '地址82', 'profile2.jpg', '自我介紹82', '09123450081'),
(85, '測試用戶83', '公司83', 'test83@example.com', '地址83', 'profile3.jpg', '自我介紹83', '09123450082'),
(86, '測試用戶84', '公司84', 'test84@example.com', '地址84', 'profile4.jpg', '自我介紹84', '09123450083'),
(87, '測試用戶85', '公司85', 'test85@example.com', '地址85', 'profile5.jpg', '自我介紹85', '09123450084'),
(88, '測試用戶86', '公司86', 'test86@example.com', '地址86', 'profile1.jpg', '自我介紹86', '09123450085'),
(89, '測試用戶87', '公司87', 'test87@example.com', '地址87', 'profile2.jpg', '自我介紹87', '09123450086'),
(90, '測試用戶88', '公司88', 'test88@example.com', '地址88', 'profile3.jpg', '自我介紹88', '09123450087'),
(91, '測試用戶89', '公司89', 'test89@example.com', '地址89', 'profile4.jpg', '自我介紹89', '09123450088'),
(92, '測試用戶90', '公司90', 'test90@example.com', '地址90', 'profile5.jpg', '自我介紹90', '09123450089'),
(93, '測試用戶91', '公司91', 'test91@example.com', '地址91', 'profile1.jpg', '自我介紹91', '09123450090'),
(94, '測試用戶92', '公司92', 'test92@example.com', '地址92', 'profile2.jpg', '自我介紹92', '09123450091'),
(95, '測試用戶93', '公司93', 'test93@example.com', '地址93', 'profile3.jpg', '自我介紹93', '09123450092'),
(96, '測試用戶94', '公司94', 'test94@example.com', '地址94', 'profile4.jpg', '自我介紹94', '09123450093'),
(97, '測試用戶95', '公司95', 'test95@example.com', '地址95', 'profile5.jpg', '自我介紹95', '09123450094'),
(98, '測試用戶96', '公司96', 'test96@example.com', '地址96', 'profile1.jpg', '自我介紹96', '09123450095'),
(99, '測試用戶97', '公司97', 'test97@example.com', '地址97', 'profile2.jpg', '自我介紹97', '09123450096'),
(100, '測試用戶98', '公司98', 'test98@example.com', '地址98', 'profile3.jpg', '自我介紹98', '09123450097');

-- --------------------------------------------------------

--
-- 資料表結構 `seller_accounts`
--

CREATE TABLE `seller_accounts` (
  `seller_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `seller_accounts`
--

INSERT INTO `seller_accounts` (`seller_id`, `username`, `password`) VALUES
(1, 'seller1_username', 'seller1_password'),
(2, 'seller2_username', 'seller2_password');

--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `seller_id` (`seller_id`);

--
-- 資料表索引 `sellers`
--
ALTER TABLE `sellers`
  ADD PRIMARY KEY (`seller_id`);

--
-- 資料表索引 `seller_accounts`
--
ALTER TABLE `seller_accounts`
  ADD PRIMARY KEY (`seller_id`);

--
-- 在傾印的資料表使用自動遞增(AUTO_INCREMENT)
--

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `sellers`
--
ALTER TABLE `sellers`
  MODIFY `seller_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2203;

--
-- 已傾印資料表的限制式
--

--
-- 資料表的限制式 `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`seller_id`) REFERENCES `sellers` (`seller_id`);

--
-- 資料表的限制式 `seller_accounts`
--
ALTER TABLE `seller_accounts`
  ADD CONSTRAINT `seller_accounts_ibfk_1` FOREIGN KEY (`seller_id`) REFERENCES `sellers` (`seller_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
