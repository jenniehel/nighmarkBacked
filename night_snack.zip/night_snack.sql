-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- 主機： 127.0.0.1
-- 產生時間： 2024-01-31 09:58:06
-- 伺服器版本： 10.4.32-MariaDB
-- PHP 版本： 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `night_snack`
--

-- --------------------------------------------------------

--
-- 資料表結構 `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `category` varchar(255) DEFAULT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_description` text DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `price` int(20) NOT NULL,
  `stock_quantity` int(11) NOT NULL,
  `listing_date` date NOT NULL DEFAULT current_timestamp(),
  `status` varchar(50) NOT NULL,
  `seller_id` int(11) DEFAULT NULL,
  `points_price` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `products`
--

INSERT INTO `products` (`product_id`, `category`, `product_name`, `product_description`, `image_url`, `price`, `stock_quantity`, `listing_date`, `status`, `seller_id`, `points_price`, `category_id`) VALUES
(1, '點心', '可麗餅', '酥脆可口的可麗餅', 'crepe_image.jpg', 90, 555, '2024-01-08', '上架中', 1, 60, 1),
(2, '飲料', '珍珠奶茶', '香濃奶茶搭配Q彈珍珠', 'bubble_tea_image.jpg', 60, 80, '2024-01-21', '上架中', 1, 55, 2),
(3, '小吃', '雞排', '酥脆美味的雞排', 'chicken_cutlet_image.jpg', 100, 60, '2024-01-21', '上架中', 1, 70, 5),
(4, '飲料', '木瓜牛奶', '香濃牛奶搭配新鮮木瓜', 'papaya_milk_image.jpg', 60, 75, '2024-01-21', '上架中', 1, 60, 2),
(5, '小吃', '蚵仔煎', '酥脆美味的台灣小吃', 'oyster_omelette_image.jpg', 50, 40, '2024-01-21', '上架中', 1, 80, 5),
(6, '主食', '火雞肉飯', '美味的火雞肉搭配香噴噴的白飯', 'turkey_rice_image.jpg', 50, 55, '2024-01-21', '上架中', 2, 65, 6),
(7, '主食', '鱔魚意麵', '美味的鱔魚搭配暖呼呼的意麵', 'eel_pasta_image.jpg', 45, 30, '2024-01-21', '上架中', 2, 90, 6),
(8, '小吃', '棺材板', '多種配料的美味烤吐司', 'mixed_toast_image.jpg', 75, 45, '2024-01-21', '上架中', 2, 70, 5),
(9, '小吃', '潤餅', '台灣傳統美食，薄餅包裹豐富的內餡', 'thin_pancake_image.jpg', 40, 65, '2024-01-21', '上架中', 2, 60, 5),
(10, '點心', '車輪餅', '外酥內軟的台灣傳統點心', 'wheel_cake_image.jpg', 35, 55, '2024-01-21', '上架中', 2, 50, 1),
(11, '點心', '筒仔米糕', '傳統台灣米糕，美味可口', 'tube_rice_cake_image.jpg', 35, 70, '2024-01-21', '上架中', 3, 40, 1),
(12, '點心', '黑糖糕', '香甜可口的黑糖糕點心', 'brown_sugar_cake_image.jpg', 30, 60, '2024-01-21', '上架中', 3, 45, 1),
(13, '主食', '滷肉飯', '美味的滷肉飯，香氣四溢', 'braised_pork_rice_image.jpg', 50, 50, '2024-01-21', '上架中', 3, 70, 6),
(14, '湯品', '土魠魚羹', '清爽美味的土魠魚羹湯品', 'fish_soup_image.jpg', 50, 40, '2024-01-21', '上架中', 3, 55, 4),
(15, '小吃', '刈包', '台灣傳統美味小吃，虎咬豬，多種配料搭配口感獨特的麵皮', 'gua_bao_image.jpg', 45, 45, '2024-01-21', '上架中', 3, 75, 5),
(16, '點心', '小籠包', '鮮美的小籠包，湯汁豐富', 'xiaolongbao_image.jpg', 70, 35, '2024-01-21', '上架中', 4, 85, 1),
(17, '小吃', '大腸包小腸', '像熱狗般的「雙腸」組合，讓你每一口都充滿驚奇', 'sausage_in_large_intestine_image.jpg', 55, 50, '2024-01-21', '上架中', 4, 65, 5),
(18, '小吃', '臭豆腐', '風靡夜市的台灣特色小吃，炸到金黃香酥的臭豆腐，淋上帶有甜味的蒜蓉醬再搭泡菜後爆表好吃', 'stinky_tofu_image.jpg', 45, 40, '2024-01-21', '上架中', 4, 55, 5),
(19, '甜品', '豆花', '清涼爽口，入口即化的豆花 ', 'tofu_pudding_image.jpg', 30, 60, '2024-01-21', '上架中', 4, 45, 3),
(20, '主食', '鹽酥雞', '雞肉外脆內嫩的鮮嫩口感，加上獨特的香料調味和配方使每一口都充滿風味，更有九層塔、生蒜碎等，一口咬下鹹香夠味的好滋味，加上多層次的調味，讓人一吃就著迷，忍不住一口接著一口吃不停。', 'popcorn_chicken_image.jpg', 120, 50, '2024-01-21', '上架中', 4, 70, 6),
(21, '點心', '地瓜球', '甜蜜美味的地瓜球點心', 'sweet_potato_balls_image.jpg', 45, 60, '2024-01-21', '上架中', 5, 45, 1),
(22, '點心', '白糖粿', '由糯米糰製成的白糖粿，油炸過後，熱熱的沾上白糖、花生粉吃，外酥內軟非常好吃', 'white_sugar_cake_image.jpg', 30, 55, '2024-01-21', '上架中', 5, 50, 1),
(23, '主食', '營養三明治', '炸得金黃酥脆的麵包，配上滷蛋、火腿、黃瓜、番茄等內餡，再擠上重頭戲、濃郁的美乃滋，一口咬下，唇齒留香', 'nutritious_sandwich_image.jpg', 45, 40, '2024-01-21', '上架中', 5, 80, 6),
(24, '主食', '天婦羅', '日式炸物，外酥內嫩', 'tempura_image.jpg', 130, 35, '2024-01-21', '上架中', 5, 85, 6),
(25, '湯品', '肉羹湯', '滑順的羹湯搭配各種脆口的食材，肉條經過香辛料、金黃蒜油裹粉醃漬燙過，口感軟嫩、蒜味濃郁，濃郁的香菇風味使柴魚湯底層次更濃厚豐富！每一口都是滿滿的台灣味', 'meat_soup_image.jpg', 35, 45, '2024-01-21', '上架中', 5, 65, 4),
(26, '主食', '夜市牛排', '入口即化的牛肉、現炒鐵板麵淋上蘑菇醬、佐營養三色豆，加上一顆生雞蛋，半熟吃實在美味', 'night_market_steak_image.jpg', 120, 30, '2024-01-21', '上架中', 1, 120, 6),
(27, '甜品', '糖葫蘆', '番茄、草莓等食材，外成裹上一層糖衣，吃起來酸甜可口', 'candied_haw_image.jpg', 35, 70, '2024-01-21', '上架中', 2, 35, 3),
(28, '小吃', '蔥油餅', '青蔥香氣四溢，配上酥脆有嚼勁的金黃色的餅皮', 'scallion_pancake_image.jpg', 55, 55, '2024-01-21', '上架中', 3, 50, 5),
(29, '湯品', '蚵仔麵線', '鮮美的蚵仔配上細緻的麵線湯', 'oyster_mee_sua_image.jpg', 60, 40, '2024-01-21', '上架中', 4, 75, 4),
(30, '甜品', '芒果冰', '新鮮芒果搭配豐富配料的冰品', 'mango_ice_image.jpg', 110, 50, '2024-01-21', '上架中', 5, 65, 3),
(31, '點心', '鯊魚', NULL, '72a1470ab18479d8.png', 500, 50, '2024-01-30', '', NULL, NULL, NULL),
(32, '甜品', 'sss', NULL, '72a1470ab18479d8.png', 55, 55, '2024-01-30', '', NULL, NULL, NULL),
(33, '甜品', '1314rrr', NULL, '321280.jpg', 33, 333, '2024-01-30', '', NULL, NULL, NULL),
(34, '飲料', 'sssssss', NULL, '321071.jpg', 3, 33, '2024-01-30', '', NULL, NULL, NULL),
(35, '湯品', '2dddd', NULL, '22337046_p0.jpg', 33333, 0, '2024-01-30', '', NULL, NULL, NULL),
(36, '點心', 'gndm', NULL, '1.JPG', 33, 333, '2024-01-30', '', NULL, NULL, NULL),
(37, '甜品', '3333333', NULL, NULL, 33332, 333, '2024-01-30', '', NULL, NULL, NULL),
(40, '點心', '4433', '444', '52e62c98d5c74dc9f90a22d21130b17557bae049.jpg', 44, 44, '2024-01-09', '', NULL, NULL, NULL),
(41, '小吃', '測試', '測試測試', '811bc01bed991e826aaa49b59a55b31666b32078.png', 2000, 45, '2024-01-10', '', NULL, NULL, NULL),
(42, '小吃', '測試', '測試', 'daab023761cf7569757c2b784142652c018531bd.png', 344, 444, '2024-01-26', '', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- 資料表結構 `product_categories`
--

CREATE TABLE `product_categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `product_categories`
--

INSERT INTO `product_categories` (`category_id`, `category_name`) VALUES
(1, '點心'),
(2, '飲料'),
(3, '甜品'),
(4, '湯品'),
(5, '小吃'),
(6, '主食');

-- --------------------------------------------------------

--
-- 資料表結構 `sellers`
--

CREATE TABLE `sellers` (
  `seller_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `address` text DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `introduction` text DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `business_hours_start` time DEFAULT NULL,
  `business_hours_end` time DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `sellers`
--

INSERT INTO `sellers` (`seller_id`, `name`, `company_name`, `email`, `address`, `profile_picture`, `introduction`, `phone`, `business_hours_start`, `business_hours_end`, `created_at`) VALUES
(1, '陳小吃攤', '台灣美食有限公司', 'chenxiaochitan@example.com', '台北市夜市區1號攤位', 'https://example.com/chenxiaochi.jpg', '歡迎品嚐我們的美味夜市小吃。', '2', '05:00:00', '22:00:00', '2024-01-29 06:02:53'),
(2, '林小吃攤', '夜市好味有限公司', 'linxiaochitan@example.com', '台中市夜市區2號攤位', 'https://example.com/linxiaochi.jpg', '專業製作各種美味小吃，品質保證。', '4', '05:00:00', '22:00:00', '2024-01-29 06:02:53'),
(3, '張小吃攤', '夜市好味小吃有限公司', 'zhangxiaochitan@example.com', '高雄市夜市區3號攤位', 'https://example.com/zhangxiaochi.jpg', '新鮮食材，美味可口，歡迎光臨。', '72322', '00:00:00', '00:00:00', '2024-01-29 06:02:53'),
(4, '李小吃攤', '夜市好味生活有限公司', 'lixiaochitan@example.com', '新竹市夜市區4號攤位', 'https://example.com/lixiaochi.jpg', '提供健康美味的夜市小吃，您的首選。', '3', '05:00:00', '22:00:00', '2024-01-29 06:02:53'),
(5, '吳小吃攤', '夜市美食樂活有限公司', 'wuxiaochitan@example.com', '彰化市夜市區5號攤位', 'https://example.com/wuxiaochi.jpg', '用心烹飪，樂活美食，歡迎品嚐。', '4', '05:00:00', '22:00:00', '2024-01-29 06:02:53'),
(2253, '新得小吃攤', '心得股份有限公司', 'explla@gmail.com', '台北市某區', NULL, '測試用攤位', '0911234567', '17:00:00', '22:00:00', '2024-01-31 06:41:30'),
(2254, '測試', '測試', '測試測試', '測試', NULL, '測試', '測試', '17:00:00', '19:00:00', '2024-01-31 07:13:26'),
(2255, '測試用攤位', '測試用', 'text123@gmail.com', '台灣', NULL, '測試', '0987654321', '08:00:00', '15:00:00', '2024-01-31 07:19:35'),
(2256, 'cccccc', 'ccccccccccc', 'cccccccccccc', 'ccccccccccc', NULL, 'cc', '1312313131', '04:00:00', '06:00:00', '2024-01-31 07:21:42'),
(2257, 's', 's', 's', 's', 'C:\\xampp\\htdocs\\myphp\\SP copy 2\\seller/upload/65b9f59ca8915_86bd849c20e2022f43b69cb4fb2bb621.jpeg', 's', NULL, '00:00:00', '00:00:00', '2024-01-31 07:24:12'),
(2258, 'c', 'c', 'c', 'c', 'C:\\xampp\\htdocs\\myphp\\SP copy 2\\seller/upload/65b9f5c58aa42_86bd849c20e2022f43b69cb4fb2bb621.jpeg', 'c', NULL, '00:00:00', '00:00:00', '2024-01-31 07:24:53'),
(2259, 'qq', 'qq', 'qq', 'qq', NULL, 'qq', NULL, '02:00:00', '07:00:00', '2024-01-31 07:27:28'),
(2260, 'e', 'e', 'e', 'e', 'C:\\xampp\\htdocs\\myphp\\SP\\seller/upload/65b9f7af7ed82_360wallpaper.jpg', 'e', NULL, '00:00:00', '00:00:00', '2024-01-31 07:33:03'),
(2261, 'te', 'tt', 'tt', 'tt', 'C:\\xampp\\htdocs\\myphp\\SP\\seller/upload/65b9fa0ff3f91_315045.jpg', 'tt', NULL, '00:00:00', '00:00:00', '2024-01-31 07:43:12'),
(2262, 'te', 'tt', 'tt', 'tt', 'C:\\xampp\\htdocs\\myphp\\SP\\seller/upload/65b9fa1955299_315045.jpg', 'tt', NULL, '00:00:00', '00:00:00', '2024-01-31 07:43:21'),
(2263, '3333333', '3333333333', '33333333333333', '3333333333333', 'C:\\xampp\\htdocs\\myphp\\SP\\seller/upload/65b9fa9ee2cff_86bd849c20e2022f43b69cb4fb2bb621.jpeg', '333', '3333333333333333', '00:00:00', '00:00:00', '2024-01-31 07:45:34'),
(2264, '222', '22222222222222', '22222222222', '222222222222222', 'C:\\xampp\\htdocs\\myphp\\SP\\seller/upload/65b9fb078602b_1431679_1356916805XXki.png', '222', '22', '02:00:00', '11:00:00', '2024-01-31 07:47:19'),
(2265, '444', '44', '44', '44', NULL, '4', '4', '00:00:00', '00:00:00', '2024-01-31 07:48:03'),
(2266, '444444', '44444444444', '444444444444', '44444444444444', 'C:\\xampp\\htdocs\\myphp\\SP copy 3\\seller/upload/65b9fb4bd34b9_318041.jpg', '4', '444444444444444', '00:00:00', '00:00:00', '2024-01-31 07:48:27'),
(2267, 'QQ', 'qq', 'qq', 'qq', 'C:\\xampp\\htdocs\\myphp\\SP\\seller/upload/65b9fba389dc5_1.JPG', 'qqq', 'qqqq', '00:00:00', '00:00:00', '2024-01-31 07:49:55'),
(2268, 'WW', 'w', 'w', 'w', NULL, 'w', 'w', '11:00:00', '17:00:00', '2024-01-31 08:01:25'),
(2269, 'sss', 'ss', 'ss', 'nop', 'C:\\xampp\\htdocs\\myphp\\SP\\seller/upload/65b9ff29774c0_360wallpaper.jpg', 'sss', 'ss', '00:00:17', '00:00:23', '2024-01-31 08:04:57'),
(2271, 'd', 'ddddddddddddd', 'dddddddddd', 'ddddddddddddd', 'C:\\xampp\\htdocs\\myphp\\SP\\seller/upload/65b9ffca51663_6cf93e61a9590351bed073dea20d044a.jpeg', 'ddccc', 'dddddddddddddd', '00:00:00', '00:00:00', '2024-01-31 08:07:38'),
(2272, '測試', '測試', '測試', '測試', 'C:\\xampp\\htdocs\\myphp\\SP\\seller/upload/65ba091ed734d_72a1470ab18479d8.png', '測試cccccc', '測試', '00:00:00', '00:00:00', '2024-01-31 08:47:26');

-- --------------------------------------------------------

--
-- 資料表結構 `seller_accounts`
--

CREATE TABLE `seller_accounts` (
  `seller_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `seller_accounts`
--

INSERT INTO `seller_accounts` (`seller_id`, `username`, `password`) VALUES
(1, 'seller1_username', 'seller1_password'),
(2, 'seller2_username', 'seller2_password'),
(3, 'seller3_username', 'seller3_password'),
(4, 'seller4_username', 'seller4_password'),
(5, 'seller5_username', 'seller5_password');

--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `seller_id` (`seller_id`),
  ADD KEY `category_id` (`category_id`);

--
-- 資料表索引 `product_categories`
--
ALTER TABLE `product_categories`
  ADD PRIMARY KEY (`category_id`);

--
-- 資料表索引 `sellers`
--
ALTER TABLE `sellers`
  ADD PRIMARY KEY (`seller_id`);

--
-- 資料表索引 `seller_accounts`
--
ALTER TABLE `seller_accounts`
  ADD PRIMARY KEY (`seller_id`);

--
-- 在傾印的資料表使用自動遞增(AUTO_INCREMENT)
--

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `sellers`
--
ALTER TABLE `sellers`
  MODIFY `seller_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2273;

--
-- 已傾印資料表的限制式
--

--
-- 資料表的限制式 `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`seller_id`) REFERENCES `sellers` (`seller_id`),
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `product_categories` (`category_id`);

--
-- 資料表的限制式 `seller_accounts`
--
ALTER TABLE `seller_accounts`
  ADD CONSTRAINT `seller_accounts_ibfk_1` FOREIGN KEY (`seller_id`) REFERENCES `sellers` (`seller_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
